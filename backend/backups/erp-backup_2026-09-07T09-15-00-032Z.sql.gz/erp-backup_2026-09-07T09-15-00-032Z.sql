-- ERP database backup
-- database: erp_db
-- generated: 2026-09-07T09:15:00.039Z
SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

DROP TABLE IF EXISTS `barcode_counters`;
CREATE TABLE `barcode_counters` (
  `id` varchar(16) NOT NULL,
  `next_val` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `barcode_counters` (`id`, `next_val`) VALUES
('default', '3');

DROP TABLE IF EXISTS `currencies`;
CREATE TABLE `currencies` (
  `id` varchar(36) NOT NULL,
  `code` varchar(8) NOT NULL,
  `name` varchar(64) NOT NULL,
  `symbol` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_9f8d0972aeeb5a2277e40332d2` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `currencies` (`id`, `code`, `name`, `symbol`) VALUES
('3d643505-c1fa-451a-88d9-7f49f6fb9ee6', 'EUR', 'Euro', '€'),
('73db763b-fb3a-427c-acd9-4b583e95656b', 'USD', 'US Dollar', '$'),
('7af04309-6c26-4518-ae70-7d9046f7ad18', 'SAR', 'Saudi Riyal', '﷼'),
('a5bb9e22-be6c-48d6-b3e5-a5818a01f7af', 'AED', 'UAE Dirham', 'د.إ');

DROP TABLE IF EXISTS `customer_documents`;
CREATE TABLE `customer_documents` (
  `id` varchar(36) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `doc_type` varchar(32) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(128) NOT NULL,
  `size` int NOT NULL,
  `storage_path` varchar(512) NOT NULL,
  `reference_no` varchar(64) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `uploaded_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `uploaded_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5301fb44d91d7a9102f12fba58` (`customer_id`),
  CONSTRAINT `FK_5301fb44d91d7a9102f12fba583` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `customer_documents` (`id`, `customer_id`, `doc_type`, `file_name`, `mime_type`, `size`, `storage_path`, `reference_no`, `issue_date`, `expiry_date`, `uploaded_at`, `uploaded_by`) VALUES
('32cc3f36-da3e-4582-b381-7ed001ad8721', '6e6b5f44-80fc-4022-833a-6894bc1ad522', 'iqama', 'door_installation_page.pdf', 'application/pdf', 2387, '/Users/admin/Lovable/v2/product-harmony-7dbd4e63/backend/uploads/customers/6e6b5f44-80fc-4022-833a-6894bc1ad522/3d182a39-2ad5-48b6-ae8e-1d225d98c5c3.pdf', NULL, NULL, NULL, '2026-07-28 13:46:56', 'dan@dan.com');

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` varchar(36) NOT NULL,
  `code` varchar(32) NOT NULL,
  `customer_type` varchar(16) NOT NULL,
  `legal_name` varchar(255) NOT NULL,
  `legal_name_ar` varchar(255) DEFAULT NULL,
  `cr_number` varchar(10) DEFAULT NULL,
  `vat_number` varchar(15) DEFAULT NULL,
  `national_id` varchar(10) DEFAULT NULL,
  `national_address_code` varchar(8) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `billing_building_number` varchar(255) DEFAULT NULL,
  `billing_street` varchar(255) DEFAULT NULL,
  `billing_district` varchar(255) DEFAULT NULL,
  `billing_city` varchar(128) DEFAULT NULL,
  `billing_postal_code` varchar(10) DEFAULT NULL,
  `billing_additional_number` varchar(10) DEFAULT NULL,
  `shipping_same_as_billing` tinyint NOT NULL DEFAULT '1',
  `shipping_building_number` varchar(255) DEFAULT NULL,
  `shipping_street` varchar(255) DEFAULT NULL,
  `shipping_district` varchar(255) DEFAULT NULL,
  `shipping_city` varchar(128) DEFAULT NULL,
  `shipping_postal_code` varchar(10) DEFAULT NULL,
  `shipping_additional_number` varchar(10) DEFAULT NULL,
  `credit_limit` decimal(14,2) NOT NULL DEFAULT '0.00',
  `currency_id` varchar(255) DEFAULT NULL,
  `payment_terms` varchar(16) NOT NULL DEFAULT 'cod',
  `status` varchar(16) NOT NULL DEFAULT 'active',
  `notes` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_f2eee14aa1fe3e956fe193c142` (`code`),
  KEY `FK_e33e99c37935c940b4515957aa4` (`currency_id`),
  CONSTRAINT `FK_e33e99c37935c940b4515957aa4` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `customers` (`id`, `code`, `customer_type`, `legal_name`, `legal_name_ar`, `cr_number`, `vat_number`, `national_id`, `national_address_code`, `phone`, `email`, `billing_building_number`, `billing_street`, `billing_district`, `billing_city`, `billing_postal_code`, `billing_additional_number`, `shipping_same_as_billing`, `shipping_building_number`, `shipping_street`, `shipping_district`, `shipping_city`, `shipping_postal_code`, `shipping_additional_number`, `credit_limit`, `currency_id`, `payment_terms`, `status`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
('6e6b5f44-80fc-4022-833a-6894bc1ad522', 'C-000001', 'individual', 'asdadasd', 'dddd', NULL, NULL, '1292192912', NULL, '+966534567890', 'dankabesh@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', NULL, 'cod', 'active', 'dddd', '2026-07-27 11:50:34', 'dan@dan.com', '2026-07-27 11:50:34', 'dan@dan.com');

DROP TABLE IF EXISTS `db_backups`;
CREATE TABLE `db_backups` (
  `id` varchar(36) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_path` varchar(512) NOT NULL,
  `trigger` varchar(16) NOT NULL,
  `status` varchar(16) NOT NULL,
  `size_bytes` bigint NOT NULL DEFAULT '0',
  `table_count` int NOT NULL DEFAULT '0',
  `duration_ms` int NOT NULL DEFAULT '0',
  `created_by_id` varchar(36) DEFAULT NULL,
  `created_by_name` varchar(255) DEFAULT NULL,
  `drive_status` varchar(16) NOT NULL DEFAULT 'pending',
  `drive_file_id` varchar(255) DEFAULT NULL,
  `drive_uploaded_at` datetime DEFAULT NULL,
  `local_deleted` tinyint NOT NULL DEFAULT '0',
  `error` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `IDX_103821efa18cd4e753bda1316f` (`filename`),
  KEY `IDX_ed281eb50cfdcc9317322aee8d` (`trigger`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` varchar(36) NOT NULL,
  `name` varchar(128) NOT NULL,
  `code` varchar(32) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `deleted_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_91fddbe23e927e1e525c152baa` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `departments` (`id`, `name`, `code`, `location`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
('814c4698-f329-480e-9df1-71817590d399', 'Bakery', 'BAK', NULL, '2026-07-21 12:40:23', NULL, '2026-07-21 12:40:23', NULL, NULL, NULL),
('859e9d63-bc57-4093-bbc2-6bd39023621c', 'Dairy', 'DAI', NULL, '2026-07-21 12:40:23', NULL, '2026-07-21 12:40:23', NULL, NULL, NULL),
('8ace6fe5-2a82-42c2-9e8a-6ebcb6014d29', 'Grocery', 'GRO', NULL, '2026-07-21 12:40:23', NULL, '2026-07-21 12:40:23', NULL, NULL, NULL),
('ad0b3fb9-b337-4f46-9896-f7c2deba0502', 'Household', 'HOU', NULL, '2026-07-21 12:40:23', NULL, '2026-07-21 12:40:23', NULL, NULL, NULL),
('dc37a207-b4ae-4e93-ad6b-eb0ac8b2e203', 'Beverages', 'BEV', NULL, '2026-07-21 12:40:23', NULL, '2026-07-21 12:40:23', NULL, NULL, NULL);

DROP TABLE IF EXISTS `employee_attendance`;
CREATE TABLE `employee_attendance` (
  `id` varchar(36) NOT NULL,
  `employee_id` varchar(36) NOT NULL,
  `work_date` date NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'present',
  `check_in` time DEFAULT NULL,
  `check_out` time DEFAULT NULL,
  `worked_hours` decimal(5,2) NOT NULL DEFAULT '0.00',
  `overtime_hours` decimal(5,2) NOT NULL DEFAULT '0.00',
  `notes` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attendance_employee_day` (`employee_id`,`work_date`),
  KEY `IDX_4ea40b73b24bf50777c9601f18` (`employee_id`),
  KEY `IDX_3f64737cccabe90c89264117de` (`work_date`),
  CONSTRAINT `FK_4ea40b73b24bf50777c9601f180` FOREIGN KEY (`employee_id`) REFERENCES `employee_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `employee_attendance` (`id`, `employee_id`, `work_date`, `status`, `check_in`, `check_out`, `worked_hours`, `overtime_hours`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
('ec564105-6e99-41e3-a96a-9c41fd861174', 'f01e67ba-b7f9-44d0-8dfd-475f20f30903', '2026-08-05 21:00:00', 'present', '12:52:00', '18:55:00', '6.05', '0.00', NULL, '2026-08-06 09:52:06', 'dan1@dan.com', '2026-08-06 09:52:18', 'dan1@dan.com');

DROP TABLE IF EXISTS `employee_attendance_requests`;
CREATE TABLE `employee_attendance_requests` (
  `id` varchar(36) NOT NULL,
  `employee_id` varchar(36) NOT NULL,
  `work_date` date NOT NULL,
  `kind` varchar(8) NOT NULL,
  `requested_time` time NOT NULL,
  `current_time_value` time DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `requested_by` varchar(36) DEFAULT NULL,
  `decided_by` varchar(36) DEFAULT NULL,
  `decided_role` varchar(32) DEFAULT NULL,
  `decided_at` datetime(6) DEFAULT NULL,
  `decision_note` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `IDX_ed99706fa0fa3b1381929124aa` (`employee_id`),
  KEY `IDX_3f65e9c1c0651c0e0f8a9f397a` (`work_date`),
  KEY `IDX_40400d63d3c7543f0deff4327d` (`status`),
  CONSTRAINT `FK_ed99706fa0fa3b1381929124aab` FOREIGN KEY (`employee_id`) REFERENCES `employee_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `employee_documents`;
CREATE TABLE `employee_documents` (
  `id` varchar(36) NOT NULL,
  `employee_id` varchar(36) NOT NULL,
  `doc_type` varchar(32) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(128) NOT NULL,
  `size_bytes` int NOT NULL,
  `storage_path` varchar(512) NOT NULL,
  `uploaded_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `uploaded_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7fce49bcbfe15a73953b280994` (`employee_id`),
  CONSTRAINT `FK_7fce49bcbfe15a73953b2809944` FOREIGN KEY (`employee_id`) REFERENCES `employee_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `employee_documents` (`id`, `employee_id`, `doc_type`, `file_name`, `mime_type`, `size_bytes`, `storage_path`, `uploaded_at`, `uploaded_by`) VALUES
('59641e29-aeec-4e80-b0d4-f0133bf53144', 'f01e67ba-b7f9-44d0-8dfd-475f20f30903', 'photo', 'aaaa.jpg', 'image/jpeg', 158914, '/Users/admin/Lovable/v3/quick-launch-react/backend/uploads/employees/f01e67ba-b7f9-44d0-8dfd-475f20f30903/photo-3b57bf21-4847-4980-a799-ca599fcb0cf6.jpg', '2026-08-16 06:17:25', 'dan1@dan.com');

DROP TABLE IF EXISTS `employee_payslips`;
CREATE TABLE `employee_payslips` (
  `id` varchar(36) NOT NULL,
  `employee_id` varchar(36) NOT NULL,
  `period` varchar(7) NOT NULL,
  `basic_salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `housing_allowance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `transport_allowance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `other_allowance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `overtime_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `bonus` decimal(12,2) NOT NULL DEFAULT '0.00',
  `gosi_deduction` decimal(12,2) NOT NULL DEFAULT '0.00',
  `unpaid_leave_deduction` decimal(12,2) NOT NULL DEFAULT '0.00',
  `other_deduction` decimal(12,2) NOT NULL DEFAULT '0.00',
  `net_pay` decimal(12,2) NOT NULL DEFAULT '0.00',
  `currency_id` varchar(36) DEFAULT NULL,
  `worked_days` int NOT NULL DEFAULT '0',
  `absent_days` int NOT NULL DEFAULT '0',
  `overtime_hours` decimal(6,2) NOT NULL DEFAULT '0.00',
  `status` varchar(16) NOT NULL DEFAULT 'draft',
  `paid_at` datetime(6) DEFAULT NULL,
  `notes` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  `working_days` int NOT NULL DEFAULT '0',
  `paid_leave_days` decimal(6,2) NOT NULL DEFAULT '0.00',
  `unpaid_leave_days` decimal(6,2) NOT NULL DEFAULT '0.00',
  `auto_generated` tinyint NOT NULL DEFAULT '0',
  `cancel_reason` text,
  `deleted_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payslip_employee_period` (`employee_id`,`period`),
  KEY `IDX_922fda8ed6992d86caf8d9339c` (`employee_id`),
  KEY `IDX_460e2ccd1f06020d77946b821b` (`period`),
  KEY `FK_923657697441f5dd2f72f8a41f4` (`currency_id`),
  KEY `IDX_29bb300a81de61facbd1c4ad83` (`deleted_at`),
  CONSTRAINT `FK_922fda8ed6992d86caf8d9339cf` FOREIGN KEY (`employee_id`) REFERENCES `employee_profiles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_923657697441f5dd2f72f8a41f4` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `employee_payslips` (`id`, `employee_id`, `period`, `basic_salary`, `housing_allowance`, `transport_allowance`, `other_allowance`, `overtime_amount`, `bonus`, `gosi_deduction`, `unpaid_leave_deduction`, `other_deduction`, `net_pay`, `currency_id`, `worked_days`, `absent_days`, `overtime_hours`, `status`, `paid_at`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `working_days`, `paid_leave_days`, `unpaid_leave_days`, `auto_generated`, `cancel_reason`, `deleted_at`) VALUES
('3abcec03-c47e-47b5-bca9-857675aa3bb4', 'f01e67ba-b7f9-44d0-8dfd-475f20f30903', '2026-09', '50000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '4500.00', '0.00', '0.00', '45500.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', 0, 0, '0.00', 'paid', '2026-09-02 08:23:42', NULL, '2026-09-02 08:23:27', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-02 08:23:42', '49cfbe8e-8001-40a4-9877-b28642191ab0', 26, '0.00', '0.00', 1, NULL, NULL),
('6291f77f-5e6b-48f7-865e-c36f2209752d', 'f229b6d7-cc25-4699-9a88-4f2197e64307', '2026-09', '1500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '135.00', '0.00', '0.00', '1365.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', 0, 0, '0.00', 'cancelled', NULL, NULL, '2026-09-02 08:23:27', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-02 08:23:56', '49cfbe8e-8001-40a4-9877-b28642191ab0', 26, '0.00', '0.00', 1, NULL, NULL),
('d7210ffe-6506-4c0c-905c-87c466faf6a3', 'f01e67ba-b7f9-44d0-8dfd-475f20f30903', '2026-08', '50000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '50000.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', 1, 0, '0.00', 'paid', '2026-08-09 14:21:12', 'testing', '2026-08-09 14:20:36', 'dan1@dan.com', '2026-08-09 14:21:12', 'dan1@dan.com', 0, '0.00', '0.00', 0, NULL, NULL),
('f28ddf98-7b16-4a29-8b6d-b79a5ea5e25a', 'f229b6d7-cc25-4699-9a88-4f2197e64307', '2026-08', '1500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '135.00', '0.00', '0.00', '1365.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', 0, 0, '0.00', 'draft', NULL, NULL, '2026-08-30 07:01:18', 'payroll-scheduler', '2026-08-30 07:01:18', 'payroll-scheduler', 26, '1.00', '0.00', 1, NULL, NULL);

DROP TABLE IF EXISTS `employee_profiles`;
CREATE TABLE `employee_profiles` (
  `id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `employee_code` varchar(32) NOT NULL,
  `first_name` varchar(128) NOT NULL,
  `last_name` varchar(128) NOT NULL,
  `iqama_number` varchar(10) NOT NULL,
  `iqama_expiry` date DEFAULT NULL,
  `nationality` varchar(64) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `mobile` varchar(20) NOT NULL,
  `emergency_contact_name` varchar(128) DEFAULT NULL,
  `emergency_contact_phone` varchar(20) DEFAULT NULL,
  `address_line1` varchar(255) NOT NULL,
  `address_city` varchar(128) NOT NULL,
  `address_postal_code` varchar(10) DEFAULT NULL,
  `bank_name` varchar(128) NOT NULL,
  `bank_account_name` varchar(255) DEFAULT NULL,
  `iban` varchar(24) NOT NULL,
  `job_title` varchar(128) NOT NULL,
  `department_id` varchar(36) DEFAULT NULL,
  `join_date` date NOT NULL,
  `contract_type` varchar(16) NOT NULL DEFAULT 'full_time',
  `employment_status` varchar(16) NOT NULL DEFAULT 'active',
  `basic_salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `housing_allowance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `transport_allowance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `other_allowance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `salary_currency_id` varchar(36) DEFAULT NULL,
  `notes` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_986e309c16f09ce6cc47d674cf` (`user_id`),
  UNIQUE KEY `IDX_1b72411d5c42f4d6b2ecd0a1f8` (`employee_code`),
  UNIQUE KEY `IDX_7fd32c197f3aaea66b5362b406` (`iqama_number`),
  UNIQUE KEY `REL_986e309c16f09ce6cc47d674cf` (`user_id`),
  KEY `FK_460fcd97e0cdf808147c3d03721` (`department_id`),
  KEY `FK_a1762ad7ccc087e1c53f894accf` (`salary_currency_id`),
  CONSTRAINT `FK_460fcd97e0cdf808147c3d03721` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `FK_986e309c16f09ce6cc47d674cfe` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_a1762ad7ccc087e1c53f894accf` FOREIGN KEY (`salary_currency_id`) REFERENCES `currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `employee_profiles` (`id`, `user_id`, `employee_code`, `first_name`, `last_name`, `iqama_number`, `iqama_expiry`, `nationality`, `date_of_birth`, `mobile`, `emergency_contact_name`, `emergency_contact_phone`, `address_line1`, `address_city`, `address_postal_code`, `bank_name`, `bank_account_name`, `iban`, `job_title`, `department_id`, `join_date`, `contract_type`, `employment_status`, `basic_salary`, `housing_allowance`, `transport_allowance`, `other_allowance`, `salary_currency_id`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
('f01e67ba-b7f9-44d0-8dfd-475f20f30903', '49cfbe8e-8001-40a4-9877-b28642191ab0', 'EMP-00001', 'Dan', 'Wickramasinghe', '2627263456', NULL, NULL, NULL, '+966509876543', NULL, NULL, '203/2/1, Batalanda Road, Makola', 'Kiribathgoda', '11640', 'test', NULL, 'SA0380000000608010167519', 'test', '859e9d63-bc57-4093-bbc2-6bd39023621c', '2026-08-04 21:00:00', 'full_time', 'active', '50000.00', '0.00', '0.00', '0.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL, '2026-08-06 09:50:29', 'dan@dan.com', '2026-08-12 10:47:09', 'dan1@dan.com'),
('f229b6d7-cc25-4699-9a88-4f2197e64307', '57cfd270-dc25-4ba9-8e8b-00f738008111', 'EMP-00002', 'John', 'Lloyd', '2000000008', NULL, NULL, NULL, '+966501234567', NULL, NULL, 'test emp', 'RIyadh', NULL, 'alinma', NULL, 'SA4815000000000100000001', 'Test employee', NULL, '2026-08-23 21:00:00', 'full_time', 'active', '1500.00', '0.00', '0.00', '0.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL, '2026-08-24 07:47:14', 'dan1@dan.com', '2026-08-24 07:47:14', 'dan1@dan.com');

DROP TABLE IF EXISTS `leave_requests`;
CREATE TABLE `leave_requests` (
  `id` varchar(36) NOT NULL,
  `employee_id` varchar(36) NOT NULL,
  `leave_type` varchar(16) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `days` decimal(6,2) NOT NULL DEFAULT '0.00',
  `units` decimal(6,2) NOT NULL DEFAULT '0.00',
  `unpaid_days` decimal(6,2) NOT NULL DEFAULT '0.00',
  `reason` varchar(255) NOT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'pending_supervisor',
  `supervisor_by` varchar(255) DEFAULT NULL,
  `supervisor_at` datetime(6) DEFAULT NULL,
  `supervisor_note` varchar(255) DEFAULT NULL,
  `manager_by` varchar(255) DEFAULT NULL,
  `manager_at` datetime(6) DEFAULT NULL,
  `manager_note` varchar(255) DEFAULT NULL,
  `rejection_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  `decided_by` varchar(255) DEFAULT NULL,
  `decided_by_role` varchar(32) DEFAULT NULL,
  `decided_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_52b4b7c7d295e204add6dbe0a0` (`employee_id`),
  KEY `IDX_a9cc5df6df50aed58f4d84aa4f` (`status`),
  CONSTRAINT `FK_52b4b7c7d295e204add6dbe0a09` FOREIGN KEY (`employee_id`) REFERENCES `employee_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `leave_requests` (`id`, `employee_id`, `leave_type`, `from_date`, `to_date`, `days`, `units`, `unpaid_days`, `reason`, `status`, `supervisor_by`, `supervisor_at`, `supervisor_note`, `manager_by`, `manager_at`, `manager_note`, `rejection_reason`, `created_at`, `created_by`, `updated_at`, `updated_by`, `decided_by`, `decided_by_role`, `decided_at`) VALUES
('aa28bfe0-c011-4661-adf4-e98977f5f37c', 'f229b6d7-cc25-4699-9a88-4f2197e64307', 'casual', '2026-08-23 21:00:00', '2026-08-23 21:00:00', '1.00', '1.00', '0.00', 'test emp', 'approved', 'Dan Wickramasinghe', '2026-08-24 07:48:53', NULL, 'Dan Wickramasinghe', '2026-08-24 07:49:00', NULL, NULL, '2026-08-24 07:48:11', 'John Lloyd', '2026-08-24 07:49:00', 'Dan Wickramasinghe', NULL, NULL, NULL),
('d1dbddab-85b8-4125-b745-b19914b10778', 'f01e67ba-b7f9-44d0-8dfd-475f20f30903', 'casual', '2026-08-23 21:00:00', '2026-08-23 21:00:00', '1.00', '1.00', '0.00', 'test admin', 'approved', 'Dan Wickramasinghe', '2026-08-24 07:59:02', NULL, 'Dan Wickramasinghe', '2026-08-24 07:59:06', NULL, NULL, '2026-08-24 07:55:11', 'Dan Wickramasinghe', '2026-08-24 07:59:06', 'Dan Wickramasinghe', NULL, NULL, NULL);

DROP TABLE IF EXISTS `payroll_run_logs`;
CREATE TABLE `payroll_run_logs` (
  `id` varchar(36) NOT NULL,
  `request_id` varchar(36) NOT NULL,
  `period` varchar(7) NOT NULL,
  `trigger_type` varchar(16) NOT NULL,
  `calendar_source` varchar(24) NOT NULL,
  `source_period` varchar(7) DEFAULT NULL,
  `working_days` int NOT NULL,
  `created_count` int NOT NULL DEFAULT '0',
  `skipped_count` int NOT NULL DEFAULT '0',
  `dry_run` tinyint NOT NULL DEFAULT '0',
  `summary` varchar(255) DEFAULT NULL,
  `actor` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `IDX_df3299dfd37b210259c0063bb6` (`request_id`),
  KEY `IDX_08d7398e6147ac5541b1461b74` (`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `payroll_run_logs` (`id`, `request_id`, `period`, `trigger_type`, `calendar_source`, `source_period`, `working_days`, `created_count`, `skipped_count`, `dry_run`, `summary`, `actor`, `created_at`) VALUES
('09e57e43-e9e9-4a52-b099-284720aa35bb', '9688f180-fa09-44ab-9d52-9c0d162e7809', '2026-08', 'scheduled', 'default', NULL, 26, 1, 1, 0, '1 created, 1 skipped', 'payroll-scheduler', '2026-08-30 07:01:18'),
('0b9119aa-83ec-45ed-9202-ea52b554ea55', '4ec55946-0988-458d-8202-69f2cfcb2354', '2026-09', 'manual', 'default', NULL, 26, 2, 0, 0, '2 created, 0 skipped', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-01 09:40:46'),
('0f01c4fd-335c-44c4-9a2b-1adc1f1dfad6', '2bcc8d77-6173-4864-acd8-ca0dea83b290', '2026-09', 'manual', 'default', NULL, 26, 2, 0, 0, '2 created, 0 skipped', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-02 08:23:27'),
('3bf638d9-1bff-4259-a8f8-1678fb2036ff', '1298d142-ca52-47b1-bb5e-cc6da10db34b', '2026-09', 'test', 'default', NULL, 26, 2, 0, 1, '2 would be created, 0 skipped', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-01 09:19:19'),
('6c258996-4602-4164-ba3a-bf9c1a4d22be', 'fc65d4f6-0b88-4860-953c-d8f6f57e1a67', '2026-09', 'test', 'default', NULL, 26, 2, 0, 1, '2 would be created, 0 skipped', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-01 09:36:04'),
('b8bf0918-baae-48cc-b450-05536f644239', '9afff6b2-f76c-4624-bf22-e2843a0261bc', '2026-09', 'test', 'default', NULL, 26, 2, 0, 1, '2 would be created, 0 skipped', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-01 09:20:43'),
('bb219916-5bb4-4f72-ab57-40ef260366f5', '92dc8eb8-e367-452d-8746-d3f763ab5857', '2026-09', 'manual', 'default', NULL, 26, 2, 0, 0, '2 created, 0 skipped', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-01 09:42:27');

DROP TABLE IF EXISTS `payroll_settings`;
CREATE TABLE `payroll_settings` (
  `id` varchar(16) NOT NULL,
  `auto_generate` tinyint NOT NULL DEFAULT '1',
  `pay_day` int NOT NULL DEFAULT '25',
  `period_offset` int NOT NULL DEFAULT '0',
  `default_overtime_rate` decimal(12,2) NOT NULL DEFAULT '0.00',
  `default_gosi_percent` decimal(5,2) NOT NULL DEFAULT '9.00',
  `default_working_days` int NOT NULL DEFAULT '26',
  `last_run_period` varchar(7) DEFAULT NULL,
  `last_run_at` datetime(6) DEFAULT NULL,
  `last_run_summary` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `payroll_settings` (`id`, `auto_generate`, `pay_day`, `period_offset`, `default_overtime_rate`, `default_gosi_percent`, `default_working_days`, `last_run_period`, `last_run_at`, `last_run_summary`, `updated_at`, `updated_by`) VALUES
('default', 1, 25, 0, '0.00', '9.00', 26, '2026-09', '2026-09-02 08:23:27', '2 created, 0 skipped', '2026-09-02 08:23:27', NULL);

DROP TABLE IF EXISTS `product_history`;
CREATE TABLE `product_history` (
  `id` varchar(36) NOT NULL,
  `product_id` varchar(36) NOT NULL,
  `action` varchar(16) NOT NULL,
  `changes` json DEFAULT NULL,
  `snapshot` json DEFAULT NULL,
  `changed_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `changed_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_d0e845cfa7cb0c5f092ae9acab` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `product_history` (`id`, `product_id`, `action`, `changes`, `snapshot`, `changed_at`, `changed_by`) VALUES
('3cb2645d-7111-44f9-8660-031413e8d248', 'a279feed-e76b-4065-b465-dd7c88b3817c', 'update', '{"buyingPrice":{"to":"10.00","from":"5.00"},"sellingPrice":{"to":"20.00","from":"10.00"},"buying_currency_id":{"to":"7af04309-6c26-4518-ae70-7d9046f7ad18","from":null},"selling_currency_id":{"to":"7af04309-6c26-4518-ae70-7d9046f7ad18","from":null}}', '{"id":"a279feed-e76b-4065-b465-dd7c88b3817c","weight":"500.000","baseQty":"1.000","created_at":"2026-07-21T12:23:32.079Z","created_by":"dan@dan.com","deleted_at":null,"deleted_by":null,"updated_at":"2026-07-23T09:11:18.000Z","updated_by":"dan@dan.com","base_uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","buyingPrice":"10.00","description":"barcode","productCode":"BAK-BAR-612033","sellingPrice":"20.00","department_id":"814c4698-f329-480e-9df1-71817590d399","weight_uom_id":"0cca017a-42e1-11f1-93e0-c3e53453051e","product_barcode":"6281234000019","buying_currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18"}', '2026-07-23 09:11:18', 'dan@dan.com');

DROP TABLE IF EXISTS `product_stock`;
CREATE TABLE `product_stock` (
  `id` varchar(36) NOT NULL,
  `product_id` varchar(36) NOT NULL,
  `vendor_id` varchar(36) DEFAULT NULL,
  `batch_no` varchar(64) DEFAULT NULL,
  `qty` decimal(12,3) NOT NULL,
  `qty_uom_id` varchar(36) DEFAULT NULL,
  `buying_price_snapshot` decimal(10,2) NOT NULL,
  `buying_currency_id_snapshot` varchar(36) DEFAULT NULL,
  `selling_price_snapshot` decimal(10,2) NOT NULL,
  `selling_currency_id_snapshot` varchar(36) DEFAULT NULL,
  `manufacture_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `ordered_at` datetime(6) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'ordered',
  `notes` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `deleted_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_62a8438c36b1a42790d3cd755a` (`product_id`),
  KEY `FK_9d5c26b749f64b9db4377b69c56` (`qty_uom_id`),
  KEY `FK_e51a32311e3d9b4e8717e617077` (`buying_currency_id_snapshot`),
  KEY `FK_eda9e99723d6de4112cc2af45aa` (`selling_currency_id_snapshot`),
  KEY `FK_6f086367cd255380e9037d1aacd` (`vendor_id`),
  CONSTRAINT `FK_62a8438c36b1a42790d3cd755a1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `FK_6f086367cd255380e9037d1aacd` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`),
  CONSTRAINT `FK_9d5c26b749f64b9db4377b69c56` FOREIGN KEY (`qty_uom_id`) REFERENCES `uoms` (`id`),
  CONSTRAINT `FK_e51a32311e3d9b4e8717e617077` FOREIGN KEY (`buying_currency_id_snapshot`) REFERENCES `currencies` (`id`),
  CONSTRAINT `FK_eda9e99723d6de4112cc2af45aa` FOREIGN KEY (`selling_currency_id_snapshot`) REFERENCES `currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `product_stock` (`id`, `product_id`, `vendor_id`, `batch_no`, `qty`, `qty_uom_id`, `buying_price_snapshot`, `buying_currency_id_snapshot`, `selling_price_snapshot`, `selling_currency_id_snapshot`, `manufacture_date`, `expiry_date`, `ordered_at`, `status`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
('4ee2aec2-bacf-403a-9ffd-4f52a3a6f136', 'a279feed-e76b-4065-b465-dd7c88b3817c', '9f4d8b07-0e5b-4520-ab56-bc185f430920', NULL, '1.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '10.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '20.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL, '2026-07-30 21:00:00', '2026-07-31 11:49:18', 'inquiry_sent', NULL, '2026-07-31 11:49:18', 'dan@dan.com', '2026-07-31 11:49:18', 'dan@dan.com', NULL, NULL),
('55183d3d-a681-4734-85b2-c5be477a0812', 'e4aec157-16ad-4d63-b6b1-607399572d5c', '9f4d8b07-0e5b-4520-ab56-bc185f430920', 'b01212', '34.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '40.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '50.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '2026-09-01 21:00:00', '2026-09-29 21:00:00', '2026-09-03 10:14:08', 'invoice_received', NULL, '2026-09-03 10:14:08', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-04 10:37:02', '49cfbe8e-8001-40a4-9877-b28642191ab0', NULL, NULL),
('73f93d04-79ab-4cd2-8ab3-ee1cfecf8452', 'a279feed-e76b-4065-b465-dd7c88b3817c', NULL, '001', '50.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '5.00', NULL, '10.00', NULL, '2026-07-01 21:00:00', '2026-09-24 21:00:00', '2026-07-23 09:10:25', 'ordered', 'testing stock', '2026-07-23 09:10:25', 'dan@dan.com', '2026-08-04 12:53:03', 'dan@dan.com', '2026-07-23 09:11:30', 'dan@dan.com'),
('879b0ff3-51b1-409d-bb85-694d2d849c82', 'e4aec157-16ad-4d63-b6b1-607399572d5c', '9f4d8b07-0e5b-4520-ab56-bc185f430920', NULL, '1.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '40.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '50.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL, NULL, '2026-07-31 10:45:02', 'inquiry_sent', NULL, '2026-07-31 10:45:02', 'dan@dan.com', '2026-07-31 10:45:02', 'dan@dan.com', NULL, NULL),
('a21bb39c-240a-4900-9721-28013a0a8d25', 'e4aec157-16ad-4d63-b6b1-607399572d5c', NULL, '001', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '40.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '50.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '2026-06-30 21:00:00', '2026-07-30 21:00:00', '2026-07-25 13:36:41', 'in_warehouse', 'asd', '2026-07-25 13:36:41', 'dan@dan.com', '2026-08-04 12:53:03', 'dan@dan.com', NULL, NULL),
('b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'e4aec157-16ad-4d63-b6b1-607399572d5c', NULL, '0111', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '40.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '50.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '2026-07-28 21:00:00', '2026-07-29 21:00:00', '2026-07-29 09:03:53', 'payment_processed', 'asdas', '2026-07-29 09:03:53', 'dan@dan.com', '2026-08-04 12:53:03', 'dan@dan.com', NULL, NULL),
('de741553-3cbe-470b-a209-72f7738c84f0', 'e4aec157-16ad-4d63-b6b1-607399572d5c', '9f4d8b07-0e5b-4520-ab56-bc185f430920', NULL, '34.000', '0cca017a-42e1-11f1-93e0-c3e53453051e', '40.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '50.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL, '2026-09-29 21:00:00', '2026-09-03 10:11:23', 'inquiry_sent', NULL, '2026-09-03 10:11:23', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-03 10:11:49', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-03 10:11:49', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('e5a1ec51-a35c-4cb2-8f7b-a8c37db8255c', 'a279feed-e76b-4065-b465-dd7c88b3817c', NULL, '002', '100.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '10.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '20.00', '7af04309-6c26-4518-ae70-7d9046f7ad18', '2026-06-30 21:00:00', '2026-07-30 21:00:00', '2026-07-23 09:11:58', 'sold_out', 'testin', '2026-07-23 09:11:58', 'dan@dan.com', '2026-08-04 12:53:03', 'dan@dan.com', NULL, NULL);

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` varchar(36) NOT NULL,
  `description` text NOT NULL,
  `baseQty` decimal(10,3) NOT NULL,
  `weight` decimal(10,3) NOT NULL,
  `buyingPrice` decimal(10,2) NOT NULL,
  `sellingPrice` decimal(10,2) NOT NULL,
  `department_id` varchar(36) DEFAULT NULL,
  `productCode` varchar(255) NOT NULL,
  `base_uom_id` varchar(36) DEFAULT NULL,
  `weight_uom_id` varchar(36) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `deleted_by` varchar(255) DEFAULT NULL,
  `product_barcode` varchar(255) DEFAULT NULL,
  `buying_currency_id` varchar(36) DEFAULT NULL,
  `selling_currency_id` varchar(36) DEFAULT NULL,
  `vendor_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_3146a8c669fc3f362c02fa9e0b` (`productCode`),
  KEY `IDX_d172ea4e5cebe16407ddcd19f4` (`product_barcode`),
  KEY `FK_70b737f02e85b16ee274962cb32` (`department_id`),
  KEY `FK_a52ba44012fa2a47aca696b5c43` (`base_uom_id`),
  KEY `FK_8ba69dd185609a10b29eac5661f` (`weight_uom_id`),
  KEY `FK_7deea7e53a53502a6d629b876c6` (`buying_currency_id`),
  KEY `FK_091b1b464f9ea377adcd2a2a2e7` (`selling_currency_id`),
  KEY `FK_0e859a83f1dd6b774c20c02885d` (`vendor_id`),
  CONSTRAINT `FK_091b1b464f9ea377adcd2a2a2e7` FOREIGN KEY (`selling_currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `FK_0e859a83f1dd6b774c20c02885d` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`),
  CONSTRAINT `FK_70b737f02e85b16ee274962cb32` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `FK_7deea7e53a53502a6d629b876c6` FOREIGN KEY (`buying_currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `FK_8ba69dd185609a10b29eac5661f` FOREIGN KEY (`weight_uom_id`) REFERENCES `uoms` (`id`),
  CONSTRAINT `FK_a52ba44012fa2a47aca696b5c43` FOREIGN KEY (`base_uom_id`) REFERENCES `uoms` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `products` (`id`, `description`, `baseQty`, `weight`, `buyingPrice`, `sellingPrice`, `department_id`, `productCode`, `base_uom_id`, `weight_uom_id`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`, `product_barcode`, `buying_currency_id`, `selling_currency_id`, `vendor_id`) VALUES
('24faedc3-b8fd-45b4-ad50-269c13406fd3', 'edit again', '5.000', '250.000', '1.50', '5.00', NULL, 'test-TES-720935', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '0cca059e-42e1-11f1-93e0-c3e53453051e', '2026-05-05 09:02:00', 'system-admin', '2026-07-26 13:43:58', NULL, NULL, NULL, NULL, '7af04309-6c26-4518-ae70-7d9046f7ad18', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL),
('6b102640-2923-416b-b18b-f2c2d7ae7870', 'White Sesame seeds Indian 250g', '1.000', '250.000', '2.50', '5.00', NULL, 'test-WHI-243051', '0cca017a-42e1-11f1-93e0-c3e53453051e', '0cca017a-42e1-11f1-93e0-c3e53453051e', '2026-04-28 10:14:03', 'system-admin', '2026-07-26 13:43:58', NULL, NULL, NULL, NULL, '7af04309-6c26-4518-ae70-7d9046f7ad18', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL),
('8e10653c-03c6-4695-a2f4-058af5ff0061', 'barcode testing', '1.000', '1.000', '5.00', '10.00', NULL, 'new barcode', NULL, NULL, '2026-07-21 11:54:07', 'dan@dan.com', '2026-07-24 07:50:52', 'dan@dan.com', '2026-07-21 12:41:30', 'dan@dan.com', NULL, '7af04309-6c26-4518-ae70-7d9046f7ad18', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL),
('a279feed-e76b-4065-b465-dd7c88b3817c', 'barcode', '1.000', '500.000', '10.00', '20.00', '814c4698-f329-480e-9df1-71817590d399', 'BAK-BAR-612033', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '0cca017a-42e1-11f1-93e0-c3e53453051e', '2026-07-21 12:23:32', 'dan@dan.com', '2026-07-23 09:11:18', 'dan@dan.com', NULL, NULL, '6281234000019', '7af04309-6c26-4518-ae70-7d9046f7ad18', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL),
('c7e520b4-b617-454a-ad1f-db8c394554e4', 'refresh', '1.000', '1.000', '5.00', '10.00', 'dc37a207-b4ae-4e93-ad6b-eb0ac8b2e203', 'test-REF-963241', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '0cca049a-42e1-11f1-93e0-c3e53453051e', '2026-05-05 09:06:03', 'system-admin', '2026-08-06 14:40:19', 'dan1@dan.com', NULL, NULL, NULL, '7af04309-6c26-4518-ae70-7d9046f7ad18', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL),
('e4aec157-16ad-4d63-b6b1-607399572d5c', 'another', '5.000', '50.000', '40.00', '50.00', '814c4698-f329-480e-9df1-71817590d399', 'BAK-ANO-704931', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '0cca017a-42e1-11f1-93e0-c3e53453051e', '2026-07-21 12:25:04', 'dan@dan.com', '2026-07-24 07:50:52', 'dan@dan.com', NULL, NULL, '6281234000026', '7af04309-6c26-4518-ae70-7d9046f7ad18', '7af04309-6c26-4518-ae70-7d9046f7ad18', NULL);

DROP TABLE IF EXISTS `resignations`;
CREATE TABLE `resignations` (
  `id` varchar(36) NOT NULL,
  `employee_id` varchar(36) NOT NULL,
  `resignation_date` date NOT NULL,
  `last_working_date` date NOT NULL,
  `notice_period_days` int NOT NULL DEFAULT '30',
  `reason_type` varchar(32) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `handover_notes` varchar(1000) DEFAULT NULL,
  `handover_to` varchar(128) DEFAULT NULL,
  `contact_email` varchar(190) DEFAULT NULL,
  `contact_mobile` varchar(24) DEFAULT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'pending_supervisor',
  `benefit_basic_salary` decimal(12,2) NOT NULL DEFAULT '0.00',
  `service_months` int NOT NULL DEFAULT '0',
  `service_years` decimal(6,2) NOT NULL DEFAULT '0.00',
  `benefit_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `supervisor_by` varchar(255) DEFAULT NULL,
  `supervisor_at` datetime(6) DEFAULT NULL,
  `manager_by` varchar(255) DEFAULT NULL,
  `manager_at` datetime(6) DEFAULT NULL,
  `admin_by` varchar(255) DEFAULT NULL,
  `admin_at` datetime(6) DEFAULT NULL,
  `decided_by` varchar(255) DEFAULT NULL,
  `decided_by_role` varchar(32) DEFAULT NULL,
  `decided_at` datetime(6) DEFAULT NULL,
  `rejection_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_e8ae29a1e9883855b5e02ceac9` (`employee_id`),
  KEY `IDX_a997d0a301574910f081120b8e` (`status`),
  CONSTRAINT `FK_e8ae29a1e9883855b5e02ceac99` FOREIGN KEY (`employee_id`) REFERENCES `employee_profiles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `role_leave_policies`;
CREATE TABLE `role_leave_policies` (
  `id` varchar(36) NOT NULL,
  `role_id` varchar(36) NOT NULL,
  `leave_type` varchar(16) NOT NULL,
  `entitlement` decimal(6,2) NOT NULL DEFAULT '0.00',
  `period_unit` varchar(8) NOT NULL DEFAULT 'year',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_leave_type` (`role_id`,`leave_type`),
  CONSTRAINT `FK_22fc3f2a3882343d3a39c2a528f` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `role_leave_policies` (`id`, `role_id`, `leave_type`, `entitlement`, `period_unit`, `created_at`, `updated_at`, `updated_by`) VALUES
('048078f8-b502-4a37-a455-4d3e58bdab1c', 'f8dd8cbb-f87a-41a0-a426-953d859e7b35', 'emergency', '2.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('0bc069b1-9e88-49a1-afda-9cfeca948753', 'f8365c15-c816-4fdb-aa06-dc89adff7917', 'annual', '14.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('0bd65368-c409-4d1f-979f-1a6001f5906d', 'f8365c15-c816-4fdb-aa06-dc89adff7917', 'short', '2.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('0d4e7f9c-f501-48a0-b3b2-05567551f4cd', 'c799ec21-51f0-4495-bbce-28aab37d0a7e', 'short', '2.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('1838da07-807f-4843-b4ed-cabd90183b6c', 'f8365c15-c816-4fdb-aa06-dc89adff7917', 'medical', '4.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('3b7d3058-0095-493f-9c32-a3023a9c2579', '6a807eec-4bd0-4fa4-b821-483cc945d8d9', 'annual', '14.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('3bae7ad0-15b2-4f86-9274-26638fb5df95', '077bbd9c-2cf8-4cc7-8227-2794ef4cad35', 'emergency', '2.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('518b7033-596c-4537-bd75-5a079d2184c9', '6a807eec-4bd0-4fa4-b821-483cc945d8d9', 'casual', '1.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('670949db-c408-45c9-bdce-a3fbd8ea790e', '8bafb933-ccfa-4f30-8a08-d08f1071e9cd', 'casual', '1.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('6cfd0ca3-4018-46f3-9dcd-d896f101f9ae', '077bbd9c-2cf8-4cc7-8227-2794ef4cad35', 'medical', '4.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('753b04a4-fad3-42b2-957a-b2d7308c2881', 'f8365c15-c816-4fdb-aa06-dc89adff7917', 'casual', '1.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('7dbcacc3-94bb-4ebd-848c-0016a617ef66', 'f8dd8cbb-f87a-41a0-a426-953d859e7b35', 'annual', '14.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('7e32bcbe-a530-4922-b1b0-7c859e918623', 'f8dd8cbb-f87a-41a0-a426-953d859e7b35', 'medical', '4.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('8b332a23-4950-4028-b732-a49d87a91569', 'c799ec21-51f0-4495-bbce-28aab37d0a7e', 'annual', '14.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('8e4d0580-55e2-4215-b7a7-37b5d4a8404a', '6a807eec-4bd0-4fa4-b821-483cc945d8d9', 'short', '2.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('925d1e86-bd88-47d4-86f3-183773d66bc4', 'f8dd8cbb-f87a-41a0-a426-953d859e7b35', 'short', '2.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('9c753afe-c7df-4071-aa8a-c86649485ba3', '8bafb933-ccfa-4f30-8a08-d08f1071e9cd', 'emergency', '2.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('a648460d-0e50-4ba5-b66d-19f50328280b', '077bbd9c-2cf8-4cc7-8227-2794ef4cad35', 'annual', '14.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('a80c4344-3c65-44f9-b019-4862e51901b9', '8bafb933-ccfa-4f30-8a08-d08f1071e9cd', 'annual', '14.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('ac236b00-c36e-4bae-85ea-a398def7b15b', 'f8365c15-c816-4fdb-aa06-dc89adff7917', 'emergency', '2.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('ac680d38-e27a-45ba-ae7d-c0e41d10e0ed', '8bafb933-ccfa-4f30-8a08-d08f1071e9cd', 'short', '2.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('b260d3b8-b0c5-42ff-b49e-65a6407b71f1', '8bafb933-ccfa-4f30-8a08-d08f1071e9cd', 'medical', '4.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('b812f2c0-3557-4582-b409-54834109edb3', 'c799ec21-51f0-4495-bbce-28aab37d0a7e', 'casual', '1.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('bf2f5903-1440-4c86-a737-2c78fdb09091', '6a807eec-4bd0-4fa4-b821-483cc945d8d9', 'medical', '4.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('d20a8d48-0dd9-496e-9bea-63f37a29bfd2', 'c799ec21-51f0-4495-bbce-28aab37d0a7e', 'emergency', '2.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('d26a3ccf-63d6-48ee-bab1-3fd77583bea1', '6a807eec-4bd0-4fa4-b821-483cc945d8d9', 'emergency', '2.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('d8ac1d3f-d098-42aa-9b80-7239dade2ce2', 'c799ec21-51f0-4495-bbce-28aab37d0a7e', 'medical', '4.00', 'year', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('db4aa5d6-c1a7-4176-9343-4634ae189fee', 'f8dd8cbb-f87a-41a0-a426-953d859e7b35', 'casual', '1.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('e1669e16-df19-4f80-8724-dd67efa2332d', '077bbd9c-2cf8-4cc7-8227-2794ef4cad35', 'casual', '1.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL),
('e8e301b8-52ef-471c-87cf-21d027731252', '077bbd9c-2cf8-4cc7-8227-2794ef4cad35', 'short', '2.00', 'month', '2026-08-10 12:07:54', '2026-08-10 12:07:54', NULL);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` varchar(36) NOT NULL,
  `code` varchar(32) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_f6d54f95c31b73fb1bdd8e91d0` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `roles` (`id`, `code`, `name`) VALUES
('077bbd9c-2cf8-4cc7-8227-2794ef4cad35', 'warehouse', 'Warehouse Staff'),
('6a807eec-4bd0-4fa4-b821-483cc945d8d9', 'admin', 'Administrator'),
('8bafb933-ccfa-4f30-8a08-d08f1071e9cd', 'employee', 'Employee'),
('c799ec21-51f0-4495-bbce-28aab37d0a7e', 'manager', 'Manager'),
('f8365c15-c816-4fdb-aa06-dc89adff7917', 'sales', 'Sales Staff'),
('f8dd8cbb-f87a-41a0-a426-953d859e7b35', 'supervisor', 'Supervisor');

DROP TABLE IF EXISTS `sales_documents`;
CREATE TABLE `sales_documents` (
  `id` varchar(36) NOT NULL,
  `doc_no` varchar(32) NOT NULL,
  `doc_type` varchar(24) NOT NULL,
  `order_id` varchar(36) NOT NULL,
  `payload` json DEFAULT NULL,
  `issued_at` datetime(6) NOT NULL,
  `issued_by` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_9d44c2d9a29007fcf65270f493` (`doc_no`),
  KEY `IDX_d70608912a228b2cfdcffb8e55` (`order_id`),
  CONSTRAINT `FK_d70608912a228b2cfdcffb8e552` FOREIGN KEY (`order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `sales_documents` (`id`, `doc_no`, `doc_type`, `order_id`, `payload`, `issued_at`, `issued_by`, `created_at`) VALUES
('5a082a67-e4a4-429f-a14a-b6379586ad66', 'INV-20260812-0001', 'sales_invoice', '51be2261-1c71-4fa6-8f87-e0382a6e510f', '{"id":"51be2261-1c71-4fa6-8f87-e0382a6e510f","items":[{"id":"febc1d13-c8d9-4c1c-b518-827585af1e77","qty":"5.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"51be2261-1c71-4fa6-8f87-e0382a6e510f","stock_id":null,"uom_code":"pkt","line_total":"100.00","product_id":"a279feed-e76b-4065-b465-dd7c88b3817c","unit_price":"20.00","description":"barcode","product_code":"BAK-BAR-612033","discount_amount":"0.00","unit_cost_snapshot":"10.00","description_snapshot":"barcode","product_code_snapshot":"BAK-BAR-612033"}],"notes":null,"status":"invoiced","paid_at":null,"currency":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"customer":{"id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","code":"C-000001","email":"dankabesh@gmail.com","notes":"dddd","phone":"+966534567890","status":"active","currency":null,"cr_number":null,"created_at":"2026-07-27T11:50:34.645Z","created_by":"dan@dan.com","legal_name":"asdadasd","updated_at":"2026-07-27T11:50:34.645Z","updated_by":"dan@dan.com","vat_number":null,"currency_id":null,"national_id":"1292192912","billing_city":null,"credit_limit":"0.00","customer_type":"individual","legal_name_ar":"dddd","payment_terms":"cod","shipping_city":null,"billing_street":null,"shipping_street":null,"billing_district":null,"shipping_district":null,"billing_postal_code":null,"shipping_postal_code":null,"national_address_code":null,"billing_building_number":null,"shipping_building_number":null,"shipping_same_as_billing":true,"billing_additional_number":null,"shipping_additional_number":null},"order_no":"SO-20260812-0001","payments":[],"subtotal":"100.00","vat_rate":"15.00","created_at":"2026-08-12T06:27:29.683Z","created_by":"dan1@dan.com","deleted_at":null,"invoice_no":"INV-20260812-0001","order_date":"2026-08-12","updated_at":"2026-08-12T06:27:42.000Z","updated_by":"dan1@dan.com","vat_amount":"15.00","amount_paid":"0.00","currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","customer_id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","invoiced_at":"2026-08-12T06:27:42.760Z","total_amount":"115.00","cancel_reason":null,"currency_code":"SAR","customer_code":"C-000001","customer_name":"asdadasd","high_priority":false,"payment_state":"settled","customer_phone":"+966534567890","credit_due_date":null,"currency_symbol":"﷼","discount_amount":"0.00","outstanding_amount":"115.00","credit_pending_amount":"0.00","expected_delivery_date":"2026-08-13","credit_not_received_amount":"0.00"}', '2026-08-12 06:27:42', 'dan1@dan.com', '2026-08-12 06:27:42'),
('8401c5ca-6388-4c1c-9a26-0fb7b5e0d005', 'DO-20260812-0001', 'delivery_order', '76bc92b8-1967-42bb-b99e-c6a56dd78a1c', '{"id":"76bc92b8-1967-42bb-b99e-c6a56dd78a1c","items":[{"id":"46fbecfa-a180-4727-8a84-4ca251a8129b","qty":"6.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"76bc92b8-1967-42bb-b99e-c6a56dd78a1c","stock_id":null,"uom_code":"pkt","line_total":"300.00","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","unit_price":"50.00","description":"another","product_code":"BAK-ANO-704931","discount_amount":"0.00","unit_cost_snapshot":"40.00","description_snapshot":"another","product_code_snapshot":"BAK-ANO-704931"}],"notes":null,"status":"delivered","paid_at":null,"currency":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"customer":{"id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","code":"C-000001","email":"dankabesh@gmail.com","notes":"dddd","phone":"+966534567890","status":"active","currency":null,"cr_number":null,"created_at":"2026-07-27T11:50:34.645Z","created_by":"dan@dan.com","legal_name":"asdadasd","updated_at":"2026-07-27T11:50:34.645Z","updated_by":"dan@dan.com","vat_number":null,"currency_id":null,"national_id":"1292192912","billing_city":null,"credit_limit":"0.00","customer_type":"individual","legal_name_ar":"dddd","payment_terms":"cod","shipping_city":null,"billing_street":null,"shipping_street":null,"billing_district":null,"shipping_district":null,"billing_postal_code":null,"shipping_postal_code":null,"national_address_code":null,"billing_building_number":null,"shipping_building_number":null,"shipping_same_as_billing":true,"billing_additional_number":null,"shipping_additional_number":null},"order_no":"SO-20260812-0003","payments":[],"subtotal":"300.00","vat_rate":"15.00","created_at":"2026-08-12T07:04:27.170Z","created_by":"dan1@dan.com","deleted_at":null,"invoice_no":null,"order_date":"2026-08-12","updated_at":"2026-08-12T07:04:34.000Z","updated_by":"dan1@dan.com","vat_amount":"45.00","amount_paid":"0.00","currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","customer_id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","invoiced_at":null,"total_amount":"345.00","cancel_reason":null,"currency_code":"SAR","customer_code":"C-000001","customer_name":"asdadasd","high_priority":false,"payment_state":"settled","customer_phone":"+966534567890","credit_due_date":null,"currency_symbol":"﷼","discount_amount":"0.00","outstanding_amount":"345.00","credit_pending_amount":"0.00","expected_delivery_date":null,"credit_not_received_amount":"0.00"}', '2026-08-12 07:04:34', 'dan1@dan.com', '2026-08-12 07:04:34'),
('8539b8fe-00b1-4318-874a-05218c661ea4', 'INV-20260812-0003', 'sales_invoice', '76bc92b8-1967-42bb-b99e-c6a56dd78a1c', '{"id":"76bc92b8-1967-42bb-b99e-c6a56dd78a1c","items":[{"id":"46fbecfa-a180-4727-8a84-4ca251a8129b","qty":"6.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"76bc92b8-1967-42bb-b99e-c6a56dd78a1c","stock_id":null,"uom_code":"pkt","line_total":"300.00","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","unit_price":"50.00","description":"another","product_code":"BAK-ANO-704931","discount_amount":"0.00","unit_cost_snapshot":"40.00","description_snapshot":"another","product_code_snapshot":"BAK-ANO-704931"}],"notes":null,"status":"invoiced","paid_at":null,"currency":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"customer":{"id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","code":"C-000001","email":"dankabesh@gmail.com","notes":"dddd","phone":"+966534567890","status":"active","currency":null,"cr_number":null,"created_at":"2026-07-27T11:50:34.645Z","created_by":"dan@dan.com","legal_name":"asdadasd","updated_at":"2026-07-27T11:50:34.645Z","updated_by":"dan@dan.com","vat_number":null,"currency_id":null,"national_id":"1292192912","billing_city":null,"credit_limit":"0.00","customer_type":"individual","legal_name_ar":"dddd","payment_terms":"cod","shipping_city":null,"billing_street":null,"shipping_street":null,"billing_district":null,"shipping_district":null,"billing_postal_code":null,"shipping_postal_code":null,"national_address_code":null,"billing_building_number":null,"shipping_building_number":null,"shipping_same_as_billing":true,"billing_additional_number":null,"shipping_additional_number":null},"order_no":"SO-20260812-0003","payments":[],"subtotal":"300.00","vat_rate":"15.00","created_at":"2026-08-12T07:04:27.170Z","created_by":"dan1@dan.com","deleted_at":null,"invoice_no":"INV-20260812-0003","order_date":"2026-08-12","updated_at":"2026-08-12T07:04:36.000Z","updated_by":"dan1@dan.com","vat_amount":"45.00","amount_paid":"0.00","currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","customer_id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","invoiced_at":"2026-08-12T07:04:36.489Z","total_amount":"345.00","cancel_reason":null,"currency_code":"SAR","customer_code":"C-000001","customer_name":"asdadasd","high_priority":false,"payment_state":"settled","customer_phone":"+966534567890","credit_due_date":null,"currency_symbol":"﷼","discount_amount":"0.00","outstanding_amount":"345.00","credit_pending_amount":"0.00","expected_delivery_date":null,"credit_not_received_amount":"0.00"}', '2026-08-12 07:04:36', 'dan1@dan.com', '2026-08-12 07:04:36'),
('c3e93251-fb85-4d82-9013-3ac6df097138', 'INV-20260812-0002', 'sales_invoice', 'a4ec9123-7a8d-4372-b7d7-5356a6036469', '{"id":"a4ec9123-7a8d-4372-b7d7-5356a6036469","items":[{"id":"9380bf5d-99f6-4580-b6b0-d881e5bd98e5","qty":"10.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"a4ec9123-7a8d-4372-b7d7-5356a6036469","stock_id":null,"uom_code":"pkt","line_total":"480.00","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","unit_price":"50.00","description":"another","product_code":"BAK-ANO-704931","discount_amount":"20.00","unit_cost_snapshot":"40.00","description_snapshot":"another","product_code_snapshot":"BAK-ANO-704931"}],"notes":null,"status":"invoiced","paid_at":null,"currency":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"customer":{"id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","code":"C-000001","email":"dankabesh@gmail.com","notes":"dddd","phone":"+966534567890","status":"active","currency":null,"cr_number":null,"created_at":"2026-07-27T11:50:34.645Z","created_by":"dan@dan.com","legal_name":"asdadasd","updated_at":"2026-07-27T11:50:34.645Z","updated_by":"dan@dan.com","vat_number":null,"currency_id":null,"national_id":"1292192912","billing_city":null,"credit_limit":"0.00","customer_type":"individual","legal_name_ar":"dddd","payment_terms":"cod","shipping_city":null,"billing_street":null,"shipping_street":null,"billing_district":null,"shipping_district":null,"billing_postal_code":null,"shipping_postal_code":null,"national_address_code":null,"billing_building_number":null,"shipping_building_number":null,"shipping_same_as_billing":true,"billing_additional_number":null,"shipping_additional_number":null},"order_no":"SO-20260812-0002","payments":[],"subtotal":"480.00","vat_rate":"15.00","created_at":"2026-08-12T06:29:22.550Z","created_by":"dan1@dan.com","deleted_at":null,"invoice_no":"INV-20260812-0002","order_date":"2026-08-12","updated_at":"2026-08-12T06:29:30.000Z","updated_by":"dan1@dan.com","vat_amount":"72.00","amount_paid":"0.00","currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","customer_id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","invoiced_at":"2026-08-12T06:29:30.834Z","total_amount":"552.00","cancel_reason":null,"currency_code":"SAR","customer_code":"C-000001","customer_name":"asdadasd","high_priority":false,"payment_state":"settled","customer_phone":"+966534567890","credit_due_date":null,"currency_symbol":"﷼","discount_amount":"0.00","outstanding_amount":"552.00","credit_pending_amount":"0.00","expected_delivery_date":null,"credit_not_received_amount":"0.00"}', '2026-08-12 06:29:30', 'dan1@dan.com', '2026-08-12 06:29:30'),
('cd875754-2f14-4622-904b-1aec9a487058', 'INV-20260811-0001', 'sales_invoice', '784e1f52-5efc-4927-83d9-175ccb2fa3a6', '{"id":"784e1f52-5efc-4927-83d9-175ccb2fa3a6","items":[{"id":"a460c2a2-1be3-4bca-a76b-e009f2c70680","qty":"10.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"784e1f52-5efc-4927-83d9-175ccb2fa3a6","stock_id":null,"uom_code":"pkt","line_total":"500.00","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","unit_price":"50.00","description":"another","product_code":"BAK-ANO-704931","discount_amount":"0.00","unit_cost_snapshot":"40.00","description_snapshot":"another","product_code_snapshot":"BAK-ANO-704931"}],"notes":null,"status":"invoiced","paid_at":null,"currency":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"customer":{"id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","code":"C-000001","email":"dankabesh@gmail.com","notes":"dddd","phone":"+966534567890","status":"active","currency":null,"cr_number":null,"created_at":"2026-07-27T11:50:34.645Z","created_by":"dan@dan.com","legal_name":"asdadasd","updated_at":"2026-07-27T11:50:34.645Z","updated_by":"dan@dan.com","vat_number":null,"currency_id":null,"national_id":"1292192912","billing_city":null,"credit_limit":"0.00","customer_type":"individual","legal_name_ar":"dddd","payment_terms":"cod","shipping_city":null,"billing_street":null,"shipping_street":null,"billing_district":null,"shipping_district":null,"billing_postal_code":null,"shipping_postal_code":null,"national_address_code":null,"billing_building_number":null,"shipping_building_number":null,"shipping_same_as_billing":true,"billing_additional_number":null,"shipping_additional_number":null},"order_no":"SO-20260811-0001","subtotal":"500.00","vat_rate":"15.00","created_at":"2026-08-11T07:12:03.563Z","created_by":"dan1@dan.com","deleted_at":null,"invoice_no":"INV-20260811-0001","order_date":"2026-08-11","updated_at":"2026-08-11T07:12:07.000Z","updated_by":"dan1@dan.com","vat_amount":"75.00","amount_paid":"0.00","currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","customer_id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","invoiced_at":"2026-08-11T07:12:07.338Z","total_amount":"575.00","cancel_reason":null,"currency_code":"SAR","customer_code":"C-000001","customer_name":"asdadasd","customer_phone":"+966534567890","currency_symbol":"﷼","discount_amount":"0.00","outstanding_amount":"575.00","expected_delivery_date":"2026-08-12"}', '2026-08-11 07:12:07', 'dan1@dan.com', '2026-08-11 07:12:07'),
('f5211c51-aaff-4171-a67c-ffa54766e375', 'INV-20260810-0001', 'sales_invoice', 'e1cea2d1-66c7-4f25-b284-6fce945491b6', '{"id":"e1cea2d1-66c7-4f25-b284-6fce945491b6","items":[{"id":"398f2116-4733-4d1e-82b0-817dfcc9149f","qty":"10.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"e1cea2d1-66c7-4f25-b284-6fce945491b6","stock_id":null,"uom_code":"pkt","line_total":"50.00","product_id":"24faedc3-b8fd-45b4-ad50-269c13406fd3","unit_price":"5.00","description":"edit again","product_code":"test-TES-720935","discount_amount":"0.00","unit_cost_snapshot":"1.50","description_snapshot":"edit again","product_code_snapshot":"test-TES-720935"},{"id":"a5f98d3b-2a5f-4b97-801e-0edc59f19f29","qty":"10.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"e1cea2d1-66c7-4f25-b284-6fce945491b6","stock_id":null,"uom_code":"pkt","line_total":"200.00","product_id":"a279feed-e76b-4065-b465-dd7c88b3817c","unit_price":"20.00","description":"barcode","product_code":"BAK-BAR-612033","discount_amount":"0.00","unit_cost_snapshot":"10.00","description_snapshot":"barcode","product_code_snapshot":"BAK-BAR-612033"},{"id":"efb2054c-c723-4519-bb6f-2dcbcea0923a","qty":"10.000","uom":{"id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","code":"pkt","kind":"both","name":"Pack"},"uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","order_id":"e1cea2d1-66c7-4f25-b284-6fce945491b6","stock_id":null,"uom_code":"pkt","line_total":"500.00","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","unit_price":"50.00","description":"another","product_code":"BAK-ANO-704931","discount_amount":"0.00","unit_cost_snapshot":"40.00","description_snapshot":"another","product_code_snapshot":"BAK-ANO-704931"}],"notes":null,"status":"invoiced","paid_at":null,"currency":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"customer":{"id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","code":"C-000001","email":"dankabesh@gmail.com","notes":"dddd","phone":"+966534567890","status":"active","currency":null,"cr_number":null,"created_at":"2026-07-27T11:50:34.645Z","created_by":"dan@dan.com","legal_name":"asdadasd","updated_at":"2026-07-27T11:50:34.645Z","updated_by":"dan@dan.com","vat_number":null,"currency_id":null,"national_id":"1292192912","billing_city":null,"credit_limit":"0.00","customer_type":"individual","legal_name_ar":"dddd","payment_terms":"cod","shipping_city":null,"billing_street":null,"shipping_street":null,"billing_district":null,"shipping_district":null,"billing_postal_code":null,"shipping_postal_code":null,"national_address_code":null,"billing_building_number":null,"shipping_building_number":null,"shipping_same_as_billing":true,"billing_additional_number":null,"shipping_additional_number":null},"order_no":"SO-20260809-0002","subtotal":"750.00","vat_rate":"15.00","created_at":"2026-08-09T18:03:38.222Z","created_by":"dan1@dan.com","deleted_at":null,"invoice_no":"INV-20260810-0001","order_date":"2026-08-09","updated_at":"2026-08-10T12:08:19.000Z","updated_by":"dan1@dan.com","vat_amount":"112.50","amount_paid":"0.00","currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","customer_id":"6e6b5f44-80fc-4022-833a-6894bc1ad522","invoiced_at":"2026-08-10T12:08:19.526Z","total_amount":"862.50","cancel_reason":null,"currency_code":"SAR","customer_code":"C-000001","customer_name":"asdadasd","customer_phone":"+966534567890","currency_symbol":"﷼","discount_amount":"0.00","outstanding_amount":"862.50","expected_delivery_date":null}', '2026-08-10 12:08:19', 'dan1@dan.com', '2026-08-10 12:08:19');

DROP TABLE IF EXISTS `sales_history`;
CREATE TABLE `sales_history` (
  `id` varchar(36) NOT NULL,
  `order_id` varchar(36) NOT NULL,
  `action` varchar(32) NOT NULL,
  `changes` json DEFAULT NULL,
  `snapshot` json DEFAULT NULL,
  `changed_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `changed_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_c586b99cdcea43ecd6ca0bdf92` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `sales_order_items`;
CREATE TABLE `sales_order_items` (
  `id` varchar(36) NOT NULL,
  `order_id` varchar(36) NOT NULL,
  `product_id` varchar(36) NOT NULL,
  `stock_id` varchar(36) DEFAULT NULL,
  `product_code_snapshot` varchar(64) DEFAULT NULL,
  `description_snapshot` varchar(255) DEFAULT NULL,
  `qty` decimal(12,3) NOT NULL,
  `uom_id` varchar(36) DEFAULT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `unit_cost_snapshot` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(14,2) NOT NULL,
  `discount_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `IDX_03b37c70136abdfd3841f176cd` (`order_id`),
  KEY `FK_a26c8d9474f682fcb603797e78d` (`product_id`),
  KEY `FK_95d75e69a4c9bd1e8e84e21c86b` (`uom_id`),
  CONSTRAINT `FK_03b37c70136abdfd3841f176cd7` FOREIGN KEY (`order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_95d75e69a4c9bd1e8e84e21c86b` FOREIGN KEY (`uom_id`) REFERENCES `uoms` (`id`),
  CONSTRAINT `FK_a26c8d9474f682fcb603797e78d` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `sales_order_items` (`id`, `order_id`, `product_id`, `stock_id`, `product_code_snapshot`, `description_snapshot`, `qty`, `uom_id`, `unit_price`, `unit_cost_snapshot`, `discount_amount`, `line_total`, `discount_percent`) VALUES
('398f2116-4733-4d1e-82b0-817dfcc9149f', 'e1cea2d1-66c7-4f25-b284-6fce945491b6', '24faedc3-b8fd-45b4-ad50-269c13406fd3', NULL, 'test-TES-720935', 'edit again', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '5.00', '1.50', '0.00', '50.00', '0.00'),
('46fbecfa-a180-4727-8a84-4ca251a8129b', '76bc92b8-1967-42bb-b99e-c6a56dd78a1c', 'e4aec157-16ad-4d63-b6b1-607399572d5c', NULL, 'BAK-ANO-704931', 'another', '6.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '50.00', '40.00', '0.00', '300.00', '0.00'),
('617b09c8-c4ac-4689-b551-f7e9b2d912a3', '309d0f16-a50f-4104-a299-75c92549f98c', 'a279feed-e76b-4065-b465-dd7c88b3817c', NULL, 'BAK-BAR-612033', 'barcode', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '20.00', '10.00', '0.00', '200.00', '0.00'),
('9380bf5d-99f6-4580-b6b0-d881e5bd98e5', 'a4ec9123-7a8d-4372-b7d7-5356a6036469', 'e4aec157-16ad-4d63-b6b1-607399572d5c', NULL, 'BAK-ANO-704931', 'another', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '50.00', '40.00', '20.00', '480.00', '0.00'),
('a460c2a2-1be3-4bca-a76b-e009f2c70680', '784e1f52-5efc-4927-83d9-175ccb2fa3a6', 'e4aec157-16ad-4d63-b6b1-607399572d5c', NULL, 'BAK-ANO-704931', 'another', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '50.00', '40.00', '0.00', '500.00', '0.00'),
('a5f98d3b-2a5f-4b97-801e-0edc59f19f29', 'e1cea2d1-66c7-4f25-b284-6fce945491b6', 'a279feed-e76b-4065-b465-dd7c88b3817c', NULL, 'BAK-BAR-612033', 'barcode', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '20.00', '10.00', '0.00', '200.00', '0.00'),
('efb2054c-c723-4519-bb6f-2dcbcea0923a', 'e1cea2d1-66c7-4f25-b284-6fce945491b6', 'e4aec157-16ad-4d63-b6b1-607399572d5c', NULL, 'BAK-ANO-704931', 'another', '10.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '50.00', '40.00', '0.00', '500.00', '0.00'),
('febc1d13-c8d9-4c1c-b518-827585af1e77', '51be2261-1c71-4fa6-8f87-e0382a6e510f', 'a279feed-e76b-4065-b465-dd7c88b3817c', NULL, 'BAK-BAR-612033', 'barcode', '5.000', '0cc96fe4-42e1-11f1-93e0-c3e53453051e', '20.00', '10.00', '0.00', '100.00', '0.00');

DROP TABLE IF EXISTS `sales_orders`;
CREATE TABLE `sales_orders` (
  `id` varchar(36) NOT NULL,
  `order_no` varchar(32) NOT NULL,
  `customer_id` varchar(36) NOT NULL,
  `order_date` date NOT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'draft',
  `currency_id` varchar(36) DEFAULT NULL,
  `subtotal` decimal(14,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `vat_rate` decimal(5,2) NOT NULL DEFAULT '15.00',
  `vat_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(14,2) NOT NULL DEFAULT '0.00',
  `invoice_no` varchar(64) DEFAULT NULL,
  `invoiced_at` datetime(6) DEFAULT NULL,
  `paid_at` datetime(6) DEFAULT NULL,
  `cancel_reason` varchar(255) DEFAULT NULL,
  `notes` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `salesperson_id` varchar(36) DEFAULT NULL,
  `commission_percent` decimal(5,2) NOT NULL DEFAULT '10.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_22b44307726c39230dfc048888` (`order_no`),
  KEY `IDX_1fb56bee917dfd98ada56d626d` (`customer_id`),
  KEY `FK_b471e629ed25d6784470b0d8f80` (`currency_id`),
  KEY `IDX_54e4f5cb9ae0ce8b4df92344fe` (`salesperson_id`),
  CONSTRAINT `FK_1fb56bee917dfd98ada56d626de` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `FK_b471e629ed25d6784470b0d8f80` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `sales_orders` (`id`, `order_no`, `customer_id`, `order_date`, `expected_delivery_date`, `status`, `currency_id`, `subtotal`, `discount_amount`, `vat_rate`, `vat_amount`, `total_amount`, `amount_paid`, `invoice_no`, `invoiced_at`, `paid_at`, `cancel_reason`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `salesperson_id`, `commission_percent`) VALUES
('309d0f16-a50f-4104-a299-75c92549f98c', 'SO-20260809-0001', '6e6b5f44-80fc-4022-833a-6894bc1ad522', '2026-08-08 21:00:00', '2026-08-12 21:00:00', 'cancelled', '7af04309-6c26-4518-ae70-7d9046f7ad18', '200.00', '0.00', '15.00', '30.00', '230.00', '0.00', NULL, NULL, NULL, 'asda', 'testing', '2026-08-09 18:00:25', 'dan1@dan.com', '2026-08-09 18:07:13', 'dan1@dan.com', NULL, NULL, '10.00'),
('51be2261-1c71-4fa6-8f87-e0382a6e510f', 'SO-20260812-0001', '6e6b5f44-80fc-4022-833a-6894bc1ad522', '2026-08-11 21:00:00', '2026-08-12 21:00:00', 'paid', '7af04309-6c26-4518-ae70-7d9046f7ad18', '100.00', '0.00', '15.00', '15.00', '115.00', '115.00', 'INV-20260812-0001', '2026-08-12 06:27:42', '2026-08-12 06:42:09', NULL, NULL, '2026-08-12 06:27:29', 'dan1@dan.com', '2026-08-12 06:42:09', 'dan1@dan.com', NULL, NULL, '10.00'),
('76bc92b8-1967-42bb-b99e-c6a56dd78a1c', 'SO-20260812-0003', '6e6b5f44-80fc-4022-833a-6894bc1ad522', '2026-08-11 21:00:00', NULL, 'invoiced', '7af04309-6c26-4518-ae70-7d9046f7ad18', '300.00', '0.00', '15.00', '45.00', '345.00', '0.00', 'INV-20260812-0003', '2026-08-12 07:04:36', NULL, NULL, NULL, '2026-08-12 07:04:27', 'dan1@dan.com', '2026-08-12 07:04:36', 'dan1@dan.com', NULL, NULL, '10.00'),
('784e1f52-5efc-4927-83d9-175ccb2fa3a6', 'SO-20260811-0001', '6e6b5f44-80fc-4022-833a-6894bc1ad522', '2026-08-10 21:00:00', '2026-08-11 21:00:00', 'paid', '7af04309-6c26-4518-ae70-7d9046f7ad18', '500.00', '0.00', '15.00', '75.00', '575.00', '575.00', 'INV-20260811-0001', '2026-08-11 07:12:07', '2026-08-11 07:13:08', NULL, NULL, '2026-08-11 07:12:03', 'dan1@dan.com', '2026-08-11 07:13:08', 'dan1@dan.com', NULL, NULL, '10.00'),
('a4ec9123-7a8d-4372-b7d7-5356a6036469', 'SO-20260812-0002', '6e6b5f44-80fc-4022-833a-6894bc1ad522', '2026-08-11 21:00:00', NULL, 'paid', '7af04309-6c26-4518-ae70-7d9046f7ad18', '480.00', '0.00', '15.00', '72.00', '552.00', '552.00', 'INV-20260812-0002', '2026-08-12 06:29:30', '2026-08-12 06:52:48', NULL, NULL, '2026-08-12 06:29:22', 'dan1@dan.com', '2026-08-12 06:52:48', 'dan1@dan.com', NULL, NULL, '10.00'),
('e1cea2d1-66c7-4f25-b284-6fce945491b6', 'SO-20260809-0002', '6e6b5f44-80fc-4022-833a-6894bc1ad522', '2026-08-08 21:00:00', NULL, 'paid', '7af04309-6c26-4518-ae70-7d9046f7ad18', '750.00', '0.00', '15.00', '112.50', '862.50', '862.50', 'INV-20260810-0001', '2026-08-10 12:08:19', '2026-08-10 12:08:38', NULL, NULL, '2026-08-09 18:03:38', 'dan1@dan.com', '2026-08-10 12:08:39', 'dan1@dan.com', NULL, NULL, '10.00');

DROP TABLE IF EXISTS `sales_payments`;
CREATE TABLE `sales_payments` (
  `id` varchar(36) NOT NULL,
  `order_id` varchar(36) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `method` varchar(24) NOT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'received',
  `proof_doc_no` varchar(64) DEFAULT NULL,
  `proof_file_name` varchar(255) DEFAULT NULL,
  `proof_file_data` longtext,
  `bank_reference` varchar(64) DEFAULT NULL,
  `credit_reference` varchar(64) DEFAULT NULL,
  `credit_days` int DEFAULT NULL,
  `expected_date` date DEFAULT NULL,
  `confirmed_at` datetime(6) DEFAULT NULL,
  `confirmed_by` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `IDX_21cb59b86093b87655b2b57ba4` (`order_id`),
  CONSTRAINT `FK_21cb59b86093b87655b2b57ba4a` FOREIGN KEY (`order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `sales_payments` (`id`, `order_id`, `amount`, `method`, `status`, `proof_doc_no`, `proof_file_name`, `proof_file_data`, `bank_reference`, `credit_reference`, `credit_days`, `expected_date`, `confirmed_at`, `confirmed_by`, `note`, `created_at`, `created_by`, `updated_at`) VALUES
('4929631a-326f-4749-b419-371504205c31', 'a4ec9123-7a8d-4372-b7d7-5356a6036469', '552.00', 'cash', 'received', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-08-12 06:52:48', 'dan1@dan.com', NULL, '2026-08-12 06:52:48', 'dan1@dan.com', '2026-08-12 06:52:48');

DROP TABLE IF EXISTS `stock_adjustments`;
CREATE TABLE `stock_adjustments` (
  `id` varchar(36) NOT NULL,
  `product_id` varchar(36) NOT NULL,
  `stock_id` varchar(36) DEFAULT NULL,
  `vendor_id` varchar(36) DEFAULT NULL,
  `type` varchar(32) NOT NULL,
  `qty` decimal(12,3) NOT NULL,
  `reference_no` varchar(64) DEFAULT NULL,
  `reason` text,
  `adjusted_at` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `deleted_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_aec247181f0d73ffe0393013a1` (`product_id`),
  KEY `FK_674b345ffd0efaae90570d6614e` (`stock_id`),
  KEY `FK_90f663ec48012f3df519b73b9b0` (`vendor_id`),
  CONSTRAINT `FK_674b345ffd0efaae90570d6614e` FOREIGN KEY (`stock_id`) REFERENCES `product_stock` (`id`),
  CONSTRAINT `FK_90f663ec48012f3df519b73b9b0` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`),
  CONSTRAINT `FK_aec247181f0d73ffe0393013a15` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `stock_attachments`;
CREATE TABLE `stock_attachments` (
  `id` varchar(36) NOT NULL,
  `stock_id` varchar(36) NOT NULL,
  `stage` varchar(32) NOT NULL DEFAULT 'general',
  `stock_document_id` varchar(36) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(128) NOT NULL,
  `size` int NOT NULL,
  `storage_path` varchar(512) NOT NULL,
  `reference_no` varchar(64) DEFAULT NULL,
  `notes` text,
  `uploaded_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `uploaded_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_fddec85e8abdcfed7944cbd528` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `stock_documents`;
CREATE TABLE `stock_documents` (
  `id` varchar(36) NOT NULL,
  `stock_id` varchar(36) NOT NULL,
  `doc_type` varchar(32) NOT NULL,
  `doc_number` varchar(64) NOT NULL,
  `payload` json DEFAULT NULL,
  `generated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `generated_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `deleted_at` datetime(6) DEFAULT NULL,
  `total_amount` decimal(14,2) DEFAULT NULL,
  `currency_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_907dfb2ce72390f4d82744e60e` (`doc_number`),
  KEY `IDX_ff5e66dc46ba0eac88d640d700` (`stock_id`),
  KEY `FK_55ae1afe6e2e1c9e91f27720124` (`currency_id`),
  CONSTRAINT `FK_55ae1afe6e2e1c9e91f27720124` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `stock_documents` (`id`, `stock_id`, `doc_type`, `doc_number`, `payload`, `generated_at`, `generated_by`, `updated_at`, `deleted_at`, `total_amount`, `currency_id`) VALUES
('0d6e2305-4465-424e-aea6-5a46651a205f', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'vendor_invoice', 'VINV-20260729-0001', '{"amount":"1000","invoice_no":"0111","invoice_date":"2026-07-29"}', '2026-07-29 09:05:45', 'dan@dan.com', '2026-07-29 09:05:45', NULL, NULL, NULL),
('0ee94b2c-da46-47e6-b1ed-dd6608bf5cb4', '55183d3d-a681-4734-85b2-c5be477a0812', 'inquiry', 'INQ-20260903-0002', '{"vendor":"asdasd","requested_qty":"34.000"}', '2026-09-03 10:14:08', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-03 10:14:08', NULL, NULL, NULL),
('17da0708-7fda-46b9-98ea-674f918e1887', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'payment', 'PAY-20260729-0001', '{"amount":"1000","paid_at":"2026-07-29T12:06","payment_method":"CASH"}', '2026-07-29 09:06:37', 'dan@dan.com', '2026-07-29 09:06:37', NULL, NULL, NULL),
('19dc71f8-5278-4815-b7e0-0a607419b9fd', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'inquiry', 'INQ-20260729-0001', '{"vendor":"tbd","requested_qty":"10.000"}', '2026-07-29 09:03:53', 'dan@dan.com', '2026-07-29 09:03:53', NULL, NULL, NULL),
('30b914ed-a9c0-4146-ad91-a0a869224f62', '55183d3d-a681-4734-85b2-c5be477a0812', 'po', 'PO-20260903-0001', '{"batch_no":"b01212","skipped_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","approved_at":"2026-09-03T13:17","skip_reason":"testing flow skip","manufacture_date":"2026-09-02"}', '2026-09-03 10:17:44', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-03 10:17:44', NULL, '1360.00', '7af04309-6c26-4518-ae70-7d9046f7ad18'),
('404eb65b-a9fe-464f-bc57-6d47d2a70b00', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'quotation', 'QUO-20260729-0001', '{"quote_no":"0111","quote_date":"2026-07-29","valid_until":"2026-07-31"}', '2026-07-29 09:04:38', 'dan@dan.com', '2026-07-29 09:04:38', NULL, NULL, NULL),
('40b00a0c-e75c-49dd-b84d-d3e11c9a5495', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'dispatch', 'DN-20260726-0001', '{"carrier":"test","tracking_no":"t01","dispatched_at":"2026-07-26T16:57"}', '2026-07-26 13:57:51', 'dan@dan.com', '2026-07-26 13:57:51', NULL, NULL, NULL),
('6631aa8f-4c58-4d8c-b050-4cae713a6112', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'po', 'PO-20260726-0001', '{}', '2026-07-26 13:56:55', 'dan@dan.com', '2026-07-26 13:56:55', NULL, NULL, NULL),
('74e524b1-57eb-4977-a99d-11c84d9cbd99', 'e5a1ec51-a35c-4cb2-8f7b-a8c37db8255c', 'grn', 'GRN-20260724-0001', '{"notes":"test","received_at":"2026-07-24T10:44","received_qty":"100"}', '2026-07-24 07:45:01', 'dan@dan.com', '2026-07-24 07:45:01', NULL, NULL, NULL),
('7d83ab3c-c1df-466c-8871-ac0f19b621d4', '55183d3d-a681-4734-85b2-c5be477a0812', 'vendor_invoice', 'VINV-20260904-0001', '{"invoice_no":"vinv01","invoice_date":"2026-09-04"}', '2026-09-04 10:37:02', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-04 10:37:02', NULL, '1360.00', '7af04309-6c26-4518-ae70-7d9046f7ad18'),
('8376f0af-6396-4f45-96b4-9d029c0d9037', '4ee2aec2-bacf-403a-9ffd-4f52a3a6f136', 'inquiry', 'INQ-20260731-0002', '{"vendor":"asdasd","requested_qty":"1.000"}', '2026-07-31 11:49:18', 'dan@dan.com', '2026-07-31 11:49:18', NULL, NULL, NULL),
('91583a33-cf6f-43d9-80b6-256037e68a1d', 'e5a1ec51-a35c-4cb2-8f7b-a8c37db8255c', 'dispatch', 'DN-20260724-0001', '{"carrier":"dh;","tracking_no":"001","dispatched_at":"2026-07-24T10:30"}', '2026-07-24 07:43:48', 'dan@dan.com', '2026-07-24 07:43:48', NULL, NULL, NULL),
('a781838a-613c-4cd2-8aa7-5fb76b01785d', 'e5a1ec51-a35c-4cb2-8f7b-a8c37db8255c', 'putaway', 'PA-20260724-0001', '{"location":"riyadh","invoice_no":"00001"}', '2026-07-24 07:46:20', 'dan@dan.com', '2026-07-24 07:46:20', NULL, NULL, NULL),
('a9ba4a99-37fa-459f-8afd-def709d06037', '879b0ff3-51b1-409d-bb85-694d2d849c82', 'inquiry', 'INQ-20260731-0001', '{"vendor":"Vendor TBD","requested_qty":"1.000"}', '2026-07-31 10:45:02', 'dan@dan.com', '2026-07-31 10:45:02', NULL, NULL, NULL),
('b6497cf1-be85-4d1a-9113-e75144d79a3e', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'po', 'PO-20260725-0001', '{"vendor":"Vendor TBD","ordered_qty":"10.000"}', '2026-07-25 13:36:41', 'dan@dan.com', '2026-07-25 13:36:41', NULL, NULL, NULL),
('d1422496-db0a-41d6-ad27-b5f998f366b7', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'putaway', 'PA-20260727-0001', '{"location":"riyad","invoice_no":"0009"}', '2026-07-27 11:49:28', 'dan@dan.com', '2026-07-27 11:49:28', NULL, NULL, NULL),
('db7786fc-e821-4acf-86af-dbe17cbb7729', 'de741553-3cbe-470b-a209-72f7738c84f0', 'inquiry', 'INQ-20260903-0001', '{"vendor":"asdasd","requested_qty":"34.000"}', '2026-09-03 10:11:23', '49cfbe8e-8001-40a4-9877-b28642191ab0', '2026-09-03 10:11:23', NULL, NULL, NULL),
('fa47cf66-1d16-452c-812e-c0f79beb67ec', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'po', 'PO-20260729-0001', '{"approved_at":"2026-07-29T12:05"}', '2026-07-29 09:05:24', 'dan@dan.com', '2026-07-29 09:05:24', NULL, NULL, NULL),
('fd1ae504-3de5-4f55-8abb-98c782001c27', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'grn', 'GRN-20260726-0001', '{"notes":"done","received_at":"2026-07-26T17:30","received_qty":"10"}', '2026-07-26 14:30:14', 'dan@dan.com', '2026-07-26 14:30:14', NULL, NULL, NULL),
('fdca9f48-b686-4269-bf2b-3da36e2ef479', 'e5a1ec51-a35c-4cb2-8f7b-a8c37db8255c', 'sales_invoice', 'INV-20260724-0001', '{"customer":"test cus","sold_qty":"100","invoice_no":"0001"}', '2026-07-24 07:46:50', 'dan@dan.com', '2026-07-24 07:46:50', NULL, NULL, NULL);

DROP TABLE IF EXISTS `stock_history`;
CREATE TABLE `stock_history` (
  `id` varchar(36) NOT NULL,
  `stock_id` varchar(36) NOT NULL,
  `action` varchar(32) NOT NULL,
  `changes` json DEFAULT NULL,
  `snapshot` json DEFAULT NULL,
  `changed_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `changed_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5b1ccf76084011cd76f72d59cf` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `stock_history` (`id`, `stock_id`, `action`, `changes`, `snapshot`, `changed_at`, `changed_by`) VALUES
('07c81b1e-41e8-45b9-89c7-c385807441cc', '879b0ff3-51b1-409d-bb85-694d2d849c82', 'create', NULL, '{"id":"879b0ff3-51b1-409d-bb85-694d2d849c82","qty":"1.000","notes":null,"status":"inquiry_sent","batch_no":null,"vendor_id":"9f4d8b07-0e5b-4520-ab56-bc185f430920","created_at":"2026-07-31T10:45:02.194Z","created_by":"dan@dan.com","deleted_at":null,"deleted_by":null,"ordered_at":"2026-07-31T10:45:02.172Z","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","qty_uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","updated_at":"2026-07-31T10:45:02.194Z","updated_by":"dan@dan.com","expiry_date":null,"vendor_name":"Vendor TBD","manufacture_date":null,"buying_price_snapshot":"40.00","selling_price_snapshot":"50.00","buying_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18"}', '2026-07-31 10:45:02', 'dan@dan.com'),
('08d9338f-2c27-41a1-9977-005fa94eac99', 'de741553-3cbe-470b-a209-72f7738c84f0', 'create', NULL, '{"id":"de741553-3cbe-470b-a209-72f7738c84f0","qty":"34.000","notes":null,"status":"inquiry_sent","batch_no":null,"vendor_id":"9f4d8b07-0e5b-4520-ab56-bc185f430920","created_at":"2026-09-03T10:11:23.790Z","created_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","deleted_at":null,"deleted_by":null,"ordered_at":"2026-09-03T10:11:23.775Z","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","qty_uom_id":"0cca017a-42e1-11f1-93e0-c3e53453051e","updated_at":"2026-09-03T10:11:23.790Z","updated_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","expiry_date":"2026-09-30","manufacture_date":null,"buying_price_snapshot":"40.00","selling_price_snapshot":"50.00","buying_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18"}', '2026-09-03 10:11:23', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('0c20b235-65a5-409a-9b30-e357462f165d', 'de741553-3cbe-470b-a209-72f7738c84f0', 'document', '{"doc_type":"inquiry","status_to":"inquiry_sent","doc_number":"INQ-20260903-0001","status_from":"inquiry_sent","total_amount":null,"currency_code":null}', NULL, '2026-09-03 10:11:23', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('1d6a94c3-8177-46b1-a594-0f9802c1802c', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'status_change', '{"doc_type":"putaway","status_to":"in_warehouse","doc_number":"PA-20260727-0001","status_from":"received"}', NULL, '2026-07-27 11:49:28', 'dan@dan.com'),
('1e552fc7-bf72-40cf-a78c-8d26bb80f22a', '879b0ff3-51b1-409d-bb85-694d2d849c82', 'document', '{"doc_type":"inquiry","status_to":"inquiry_sent","doc_number":"INQ-20260731-0001","status_from":"inquiry_sent","total_amount":null,"currency_code":null}', NULL, '2026-07-31 10:45:02', 'dan@dan.com'),
('22d575f5-ec9c-4377-8028-1128dd50e4b4', '55183d3d-a681-4734-85b2-c5be477a0812', 'document', '{"doc_type":"inquiry","status_to":"inquiry_sent","doc_number":"INQ-20260903-0002","status_from":"inquiry_sent","total_amount":null,"currency_code":null}', NULL, '2026-09-03 10:14:08', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('393f50c9-cdac-49e9-9255-e7c4f7714a97', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'status_change', '{"doc_type":"quotation","status_to":"quotation_received","doc_number":"QUO-20260729-0001","status_from":"inquiry_sent"}', NULL, '2026-07-29 09:04:38', 'dan@dan.com'),
('3e93bdb7-3cd8-4254-829a-d5f1f13596cc', '55183d3d-a681-4734-85b2-c5be477a0812', 'create', NULL, '{"id":"55183d3d-a681-4734-85b2-c5be477a0812","qty":"34.000","notes":null,"status":"inquiry_sent","batch_no":null,"vendor_id":"9f4d8b07-0e5b-4520-ab56-bc185f430920","created_at":"2026-09-03T10:14:08.848Z","created_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","deleted_at":null,"deleted_by":null,"ordered_at":"2026-09-03T10:14:08.843Z","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","qty_uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","updated_at":"2026-09-03T10:14:08.848Z","updated_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","expiry_date":"2026-09-30","manufacture_date":"2026-09-02","buying_price_snapshot":"40.00","selling_price_snapshot":"50.00","buying_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18"}', '2026-09-03 10:14:08', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('537b410f-4bc9-42ae-96e4-0b3f6a9b57fe', '4ee2aec2-bacf-403a-9ffd-4f52a3a6f136', 'create', NULL, '{"id":"4ee2aec2-bacf-403a-9ffd-4f52a3a6f136","qty":"1.000","notes":null,"status":"inquiry_sent","batch_no":null,"vendor_id":"9f4d8b07-0e5b-4520-ab56-bc185f430920","created_at":"2026-07-31T11:49:18.931Z","created_by":"dan@dan.com","deleted_at":null,"deleted_by":null,"ordered_at":"2026-07-31T11:49:18.923Z","product_id":"a279feed-e76b-4065-b465-dd7c88b3817c","qty_uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","updated_at":"2026-07-31T11:49:18.931Z","updated_by":"dan@dan.com","expiry_date":"2026-07-31","vendor_name":"asdasd","manufacture_date":null,"buying_price_snapshot":"10.00","selling_price_snapshot":"20.00","buying_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18"}', '2026-07-31 11:49:18', 'dan@dan.com'),
('64a2e825-b117-4fe1-89ef-396334455782', '55183d3d-a681-4734-85b2-c5be477a0812', 'status_change', '{"doc_type":"vendor_invoice","status_to":"invoice_received","doc_number":"VINV-20260904-0001","status_from":"quotation_approved","total_amount":"1360.00","currency_code":"SAR"}', NULL, '2026-09-04 10:37:02', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('6d6d0fd2-a243-4515-b6ea-10d80408e95a', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'status_change', '{"doc_type":"payment","status_to":"payment_processed","doc_number":"PAY-20260729-0001","status_from":"invoice_received"}', NULL, '2026-07-29 09:06:37', 'dan@dan.com'),
('9a7eea60-c145-4491-8e8f-0631aa28d1c5', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'document', '{"doc_type":"po","status_to":"ordered","doc_number":"PO-20260726-0001","status_from":"ordered"}', NULL, '2026-07-26 13:56:55', 'dan@dan.com'),
('a0ca9463-c9ea-41fe-baec-04828f1e83b9', '55183d3d-a681-4734-85b2-c5be477a0812', 'status_change', '{"doc_type":"po","status_to":"quotation_approved","doc_number":"PO-20260903-0001","status_from":"inquiry_sent","total_amount":"1360.00","currency_code":"SAR"}', NULL, '2026-09-03 10:17:44', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('b8ed5c1f-77eb-4809-8cec-3c88ece7162c', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'status_change', '{"doc_type":"dispatch","status_to":"in_transit","doc_number":"DN-20260726-0001","status_from":"ordered"}', NULL, '2026-07-26 13:57:51', 'dan@dan.com'),
('b9eaccff-cc7e-4ea7-8119-f314b3a05164', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'status_change', '{"doc_type":"po","status_to":"quotation_approved","doc_number":"PO-20260729-0001","status_from":"quotation_received"}', NULL, '2026-07-29 09:05:24', 'dan@dan.com'),
('c7b2112c-beff-4bf5-86b4-c2212d3ee4be', 'de741553-3cbe-470b-a209-72f7738c84f0', 'delete', NULL, '{"id":"de741553-3cbe-470b-a209-72f7738c84f0","qty":"34.000","notes":null,"status":"inquiry_sent","vendor":{"id":"9f4d8b07-0e5b-4520-ab56-bc185f430920","city":null,"code":"V-000001","iban":null,"email":"dankabesh@gmail.com","notes":null,"phone":"+966509876543","status":"active","street":null,"currency":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"district":null,"bank_name":"alinma","cr_number":"1010101010","created_at":"2026-07-27T11:52:25.144Z","created_by":"dan@dan.com","legal_name":"asdasd","updated_at":"2026-07-28T06:44:19.000Z","updated_by":"dan@dan.com","vat_number":"303030303030303","currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","postal_code":null,"legal_name_ar":"kkkk","payment_terms":"net_15","contact_person":"Dan “RuRiYo” Wickramasinghe","lead_time_days":7,"building_number":null,"additional_number":null,"national_address_code":null,"import_export_license_no":null},"product":{"id":"e4aec157-16ad-4d63-b6b1-607399572d5c","weight":"50.000","baseQty":"5.000","vendor_id":null,"created_at":"2026-07-21T12:25:04.959Z","created_by":"dan@dan.com","deleted_at":null,"deleted_by":null,"updated_at":"2026-07-24T07:50:52.040Z","updated_by":"dan@dan.com","base_uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","buyingPrice":"40.00","description":"another","productCode":"BAK-ANO-704931","sellingPrice":"50.00","department_id":"814c4698-f329-480e-9df1-71817590d399","weight_uom_id":"0cca017a-42e1-11f1-93e0-c3e53453051e","product_barcode":"6281234000026","buying_currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id":"7af04309-6c26-4518-ae70-7d9046f7ad18"},"qty_uom":{"id":"0cca017a-42e1-11f1-93e0-c3e53453051e","code":"g","kind":"both","name":"Gram"},"batch_no":null,"vendor_id":"9f4d8b07-0e5b-4520-ab56-bc185f430920","created_at":"2026-09-03T10:11:23.790Z","created_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","deleted_at":"2026-09-03T10:11:49.000Z","deleted_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","ordered_at":"2026-09-03T10:11:23.775Z","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","qty_uom_id":"0cca017a-42e1-11f1-93e0-c3e53453051e","updated_at":"2026-09-03T10:11:49.000Z","updated_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","expiry_date":"2026-09-30","vendor_code":"V-000001","vendor_name":"asdasd","product_code":"BAK-ANO-704931","qty_uom_code":"g","qty_uom_name":"Gram","manufacture_date":null,"total_buying_value":"1360.00","product_description":"another","total_selling_value":"1700.00","buying_currency_code":"SAR","buying_price_snapshot":"40.00","selling_currency_code":"SAR","buying_currency_symbol":"﷼","selling_price_snapshot":"50.00","selling_currency_symbol":"﷼","buying_currency_snapshot":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"selling_currency_snapshot":{"id":"7af04309-6c26-4518-ae70-7d9046f7ad18","code":"SAR","name":"Saudi Riyal","symbol":"﷼"},"buying_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18"}', '2026-09-03 10:11:49', '49cfbe8e-8001-40a4-9877-b28642191ab0'),
('ca5b5fb0-f523-496f-8fa6-c0e567562554', '4ee2aec2-bacf-403a-9ffd-4f52a3a6f136', 'document', '{"doc_type":"inquiry","status_to":"inquiry_sent","doc_number":"INQ-20260731-0002","status_from":"inquiry_sent","total_amount":null,"currency_code":null}', NULL, '2026-07-31 11:49:18', 'dan@dan.com'),
('d1fcfeca-64a5-4fa4-818e-f88892ec3b1c', 'a21bb39c-240a-4900-9721-28013a0a8d25', 'status_change', '{"doc_type":"grn","status_to":"received","doc_number":"GRN-20260726-0001","status_from":"in_transit"}', NULL, '2026-07-26 14:30:14', 'dan@dan.com'),
('d3352e1b-c829-48b7-878f-b680c8020914', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'create', NULL, '{"id":"b40f2bc2-bd81-4b18-a51e-af25fe4687a2","qty":"10.000","notes":"asdas","status":"inquiry_sent","batch_no":"0111","vendor_id":"id","created_at":"2026-07-29T09:03:53.902Z","created_by":"dan@dan.com","deleted_at":null,"deleted_by":null,"ordered_at":"2026-07-29T09:03:53.896Z","product_id":"e4aec157-16ad-4d63-b6b1-607399572d5c","qty_uom_id":"0cc96fe4-42e1-11f1-93e0-c3e53453051e","updated_at":"2026-07-29T09:03:53.902Z","updated_by":"dan@dan.com","expiry_date":"2026-07-30","vendor_name":"tbd","manufacture_date":"2026-07-29","buying_price_snapshot":"40.00","selling_price_snapshot":"50.00","buying_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18","selling_currency_id_snapshot":"7af04309-6c26-4518-ae70-7d9046f7ad18"}', '2026-07-29 09:03:53', 'dan@dan.com'),
('ded16461-df2c-4bdd-af95-725f7d55cebf', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'status_change', '{"doc_type":"vendor_invoice","status_to":"invoice_received","doc_number":"VINV-20260729-0001","status_from":"quotation_approved"}', NULL, '2026-07-29 09:05:45', 'dan@dan.com'),
('e2594587-16c0-46b5-9def-acc03503a4bb', 'b40f2bc2-bd81-4b18-a51e-af25fe4687a2', 'document', '{"doc_type":"inquiry","status_to":"inquiry_sent","doc_number":"INQ-20260729-0001","status_from":"inquiry_sent"}', NULL, '2026-07-29 09:03:53', 'dan@dan.com');

DROP TABLE IF EXISTS `stock_stage_audit`;
CREATE TABLE `stock_stage_audit` (
  `id` varchar(36) NOT NULL,
  `stock_id` varchar(36) NOT NULL,
  `document_id` varchar(36) DEFAULT NULL,
  `doc_type` varchar(32) NOT NULL,
  `doc_number` varchar(64) DEFAULT NULL,
  `stage_label` varchar(128) NOT NULL,
  `status_from` varchar(32) DEFAULT NULL,
  `status_to` varchar(32) DEFAULT NULL,
  `result` varchar(16) NOT NULL,
  `reason` text,
  `payload` json DEFAULT NULL,
  `total_amount` decimal(14,2) DEFAULT NULL,
  `currency_code` varchar(8) DEFAULT NULL,
  `actor_email` varchar(255) DEFAULT NULL,
  `actor_role` varchar(32) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `IDX_80dd68a8b86c16c1eef27dcf66` (`stock_id`),
  KEY `IDX_4371e8e524787b3f674d86541a` (`doc_type`),
  KEY `IDX_079404c4de468706465066007f` (`actor_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `stock_stage_audit` (`id`, `stock_id`, `document_id`, `doc_type`, `doc_number`, `stage_label`, `status_from`, `status_to`, `result`, `reason`, `payload`, `total_amount`, `currency_code`, `actor_email`, `actor_role`, `created_at`) VALUES
('030c4a4d-8c29-460f-adfd-ef230b54fcc8', '55183d3d-a681-4734-85b2-c5be477a0812', NULL, 'vendor_invoice', NULL, 'Vendor Invoice', NULL, NULL, 'failed', 'Cannot generate the vendor_invoice document — this stock is missing: batch number. These are captured at the Purchase Order stage.', '{"invoice_no":"v00103092026","invoice_date":"2026-09-03"}', '1360.00', 'SAR', '49cfbe8e-8001-40a4-9877-b28642191ab0', 'admin', '2026-09-03 10:17:09'),
('73826f01-d9f2-4b00-ad82-ee0a4401dbbe', 'de741553-3cbe-470b-a209-72f7738c84f0', 'db7786fc-e821-4acf-86af-dbe17cbb7729', 'inquiry', 'INQ-20260903-0001', 'Inquiry', 'inquiry_sent', 'inquiry_sent', 'success', NULL, '{"vendor":"asdasd","requested_qty":"34.000"}', NULL, NULL, '49cfbe8e-8001-40a4-9877-b28642191ab0', NULL, '2026-09-03 10:11:23'),
('7420dfd2-8145-47d5-94c0-4a3a0096eedf', '55183d3d-a681-4734-85b2-c5be477a0812', '7d83ab3c-c1df-466c-8871-ac0f19b621d4', 'vendor_invoice', 'VINV-20260904-0001', 'Vendor Invoice', 'quotation_approved', 'invoice_received', 'success', NULL, '{"invoice_no":"vinv01","invoice_date":"2026-09-04"}', '1360.00', 'SAR', '49cfbe8e-8001-40a4-9877-b28642191ab0', 'admin', '2026-09-04 10:37:02'),
('75b11c17-a57a-469b-94de-c2a016b0a551', '55183d3d-a681-4734-85b2-c5be477a0812', '0ee94b2c-da46-47e6-b1ed-dd6608bf5cb4', 'inquiry', 'INQ-20260903-0002', 'Inquiry', 'inquiry_sent', 'inquiry_sent', 'success', NULL, '{"vendor":"asdasd","requested_qty":"34.000"}', NULL, NULL, '49cfbe8e-8001-40a4-9877-b28642191ab0', NULL, '2026-09-03 10:14:08'),
('d38e1cf2-09d1-4d12-bf9c-2c96f86c61b7', '55183d3d-a681-4734-85b2-c5be477a0812', NULL, 'vendor_invoice', NULL, 'Vendor Invoice', NULL, NULL, 'failed', 'Cannot generate the vendor_invoice document — this stock is missing: batch number. These are captured at the Purchase Order stage.', '{"invoice_no":"v00103092026","invoice_date":"2026-09-03"}', '1360.00', 'SAR', '49cfbe8e-8001-40a4-9877-b28642191ab0', 'admin', '2026-09-03 10:16:56'),
('fa06a1c8-493b-4b68-aa65-a82adef0eab9', '55183d3d-a681-4734-85b2-c5be477a0812', '30b914ed-a9c0-4146-ad91-a0a869224f62', 'po', 'PO-20260903-0001', 'Purchase Order', 'inquiry_sent', 'quotation_approved', 'success', NULL, '{"batch_no":"b01212","skipped_by":"49cfbe8e-8001-40a4-9877-b28642191ab0","approved_at":"2026-09-03T13:17","skip_reason":"testing flow skip","manufacture_date":"2026-09-02"}', '1360.00', 'SAR', '49cfbe8e-8001-40a4-9877-b28642191ab0', 'admin', '2026-09-03 10:17:44');

DROP TABLE IF EXISTS `uoms`;
CREATE TABLE `uoms` (
  `id` varchar(36) NOT NULL,
  `code` varchar(32) NOT NULL,
  `kind` varchar(16) NOT NULL DEFAULT 'both',
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_79340442d8ece5d8774d810e77` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `uoms` (`id`, `code`, `kind`, `name`) VALUES
('0cc96fe4-42e1-11f1-93e0-c3e53453051e', 'pkt', 'both', 'Pack'),
('0cca017a-42e1-11f1-93e0-c3e53453051e', 'g', 'both', 'Gram'),
('0cca049a-42e1-11f1-93e0-c3e53453051e', 'kg', 'both', 'Kilogram'),
('0cca059e-42e1-11f1-93e0-c3e53453051e', 'pcs', 'both', 'Pieces'),
('0cca06ca-42e1-11f1-93e0-c3e53453051e', 'box', 'both', 'Box'),
('392aed1f-7b18-4840-a675-568f278245a1', 'L', 'weight', 'Liter'),
('41be46a6-d6e5-4c6e-9c71-9b8627b80e97', 'ML', 'weight', 'Milliliter'),
('70beb73c-ccfa-4af5-838a-0ffe5722c634', 'PACK', 'base', 'Pack');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` varchar(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `role_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_97672ac88f789774dd47f7c8be` (`email`),
  KEY `FK_a2cecd1a3531c0b041e29ba46e1` (`role_id`),
  CONSTRAINT `FK_a2cecd1a3531c0b041e29ba46e1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `users` (`id`, `email`, `name`, `password`, `created_at`, `updated_at`, `role_id`) VALUES
('49cfbe8e-8001-40a4-9877-b28642191ab0', 'dan1@dan.com', 'Dan Wickramasinghe', '$2a$10$E2zwWp7uUOnzTSf5vDNYauoc2XepZLcLpyrLpVa5pRpV5pG8894U6', '2026-08-06 09:50:29', '2026-08-16 06:17:25', '6a807eec-4bd0-4fa4-b821-483cc945d8d9'),
('57cfd270-dc25-4ba9-8e8b-00f738008111', 'danemp@gmail.com', 'John Lloyd', '$2a$10$nomLDtAGfQtG7hbvtjJW0et2ZEM1csco14xj7JD1nubyW0mTFMi..', '2026-08-24 07:47:14', '2026-08-24 07:47:14', '8bafb933-ccfa-4f30-8a08-d08f1071e9cd'),
('c6e67338-d234-46af-9e01-e8cf87d73d7d', 'dan@dan.com', 'dan', '$2a$10$HgYV9Y.CXaiT69lIiztNkuv3Ru.VfG2OuXUFnyBhUxJV664ayRwqu', '2026-07-21 11:49:31', '2026-07-22 14:34:29', '6a807eec-4bd0-4fa4-b821-483cc945d8d9');

DROP TABLE IF EXISTS `vendor_documents`;
CREATE TABLE `vendor_documents` (
  `id` varchar(36) NOT NULL,
  `vendor_id` varchar(255) NOT NULL,
  `doc_type` varchar(32) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(128) NOT NULL,
  `size` int NOT NULL,
  `storage_path` varchar(512) NOT NULL,
  `reference_no` varchar(64) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `uploaded_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `uploaded_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_218ad2aece37d1c3bf7cfe6c72` (`vendor_id`),
  CONSTRAINT `FK_218ad2aece37d1c3bf7cfe6c72f` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `vendor_documents` (`id`, `vendor_id`, `doc_type`, `file_name`, `mime_type`, `size`, `storage_path`, `reference_no`, `issue_date`, `expiry_date`, `uploaded_at`, `uploaded_by`) VALUES
('39e6ce90-29db-43ee-bd16-bbfad7897698', '9f4d8b07-0e5b-4520-ab56-bc185f430920', 'vat', 'bank.pdf', 'application/pdf', 38737, '/Users/admin/Lovable/v2/product-harmony-7dbd4e63/backend/uploads/vendors/9f4d8b07-0e5b-4520-ab56-bc185f430920/c3524a80-ae47-4ba0-b9d8-8f058251bc89.pdf', NULL, NULL, NULL, '2026-07-28 13:45:05', 'dan@dan.com');

DROP TABLE IF EXISTS `vendor_statuses`;
CREATE TABLE `vendor_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_0e692331d0cdfec97af8833033` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `vendor_statuses` (`id`, `code`, `name`) VALUES
(1, 'PENDING', 'Pending Admin Review'),
(2, 'APPROVED', 'Approved (Active)'),
(3, 'REJECTED', 'Rejected');

DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `id` varchar(36) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  `code` varchar(32) NOT NULL,
  `legal_name` varchar(255) NOT NULL,
  `legal_name_ar` varchar(255) DEFAULT NULL,
  `national_address_code` varchar(8) DEFAULT NULL,
  `building_number` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `city` varchar(128) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `additional_number` varchar(10) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `iban` varchar(24) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `payment_terms` varchar(16) NOT NULL DEFAULT 'net_30',
  `lead_time_days` int NOT NULL DEFAULT '7',
  `currency_id` varchar(255) DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'active',
  `notes` text,
  `cr_number` varchar(10) NOT NULL,
  `vat_number` varchar(15) DEFAULT NULL,
  `import_export_license_no` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_1127015587ca66797a56938171` (`code`),
  UNIQUE KEY `IDX_ae390d45af72d997d514a3b9ee` (`cr_number`),
  KEY `FK_c12e394f60e71c52515b84b2723` (`currency_id`),
  CONSTRAINT `FK_c12e394f60e71c52515b84b2723` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `vendors` (`id`, `email`, `created_at`, `created_by`, `updated_at`, `updated_by`, `code`, `legal_name`, `legal_name_ar`, `national_address_code`, `building_number`, `street`, `district`, `city`, `postal_code`, `additional_number`, `contact_person`, `phone`, `iban`, `bank_name`, `payment_terms`, `lead_time_days`, `currency_id`, `status`, `notes`, `cr_number`, `vat_number`, `import_export_license_no`) VALUES
('9f4d8b07-0e5b-4520-ab56-bc185f430920', 'dankabesh@gmail.com', '2026-07-27 11:52:25', 'dan@dan.com', '2026-07-28 06:44:19', 'dan@dan.com', 'V-000001', 'asdasd', 'kkkk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Dan “RuRiYo” Wickramasinghe', '+966509876543', NULL, 'alinma', 'net_15', 7, '7af04309-6c26-4518-ae70-7d9046f7ad18', 'active', NULL, '1010101010', '303030303030303', NULL);

DROP TABLE IF EXISTS `work_calendars`;
CREATE TABLE `work_calendars` (
  `id` varchar(36) NOT NULL,
  `period` varchar(7) NOT NULL,
  `working_days` int NOT NULL,
  `public_holidays` int NOT NULL DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_d113b2704fc4b1ae25ab7a7f64` (`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

SET FOREIGN_KEY_CHECKS=1;
